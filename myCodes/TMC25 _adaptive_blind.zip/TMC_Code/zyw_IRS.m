%% CIE Mphil Zhang Yaowen 
% This code is used to solve norm(c.'x) where c is a vector and each
% component is a complex number. each component of x is a complex number is
% a complex number as well and xi belong to set{0,w1,w2,...} where
% d_w=exp(1j*2pi/K)

function [x1,x2,x3]=zyw_IRS(c,K)
[N0,~]=size(c);% c(1,1)stores the direct channel and c(2:N0,1) stores direct channel
N=N0-1;        % N is the number of elements, which equals N0-1
for n0=1:N0
% to obtain the argument phase of CSI and store it in c_theta, it belongs
% to [0,2pi]
    c_theta(n0,1)=angle(c(n0,1));
    if c_theta(n0,1)<0
        c_theta(n0,1)=c_theta(n0,1)+2*pi;
    end
end

for n0=1:N
% h_theta stores the relative angle between indirect channel and direct channel 
    h_theta(n0,1)=c_theta(n0+1,1)-c_theta(1,1);
    if h_theta(n0,1)<0
        h_theta(n0,1)=h_theta(n0,1)+2*pi;
    end
end
% find corresponding sector
for n0=1:N
    h1(n0,1)=mod(h_theta(n0,1),2*pi/K);
    if h1(n0,1)<pi/K
        sola(n0,1)=exp(1j*(h1(n0,1)-h_theta(n0,1)));% 1,2
        solb(n0,1)=exp(1j*(h1(n0,1)-h_theta(n0,1)));% 1,-1
        solc(n0,1)=exp(1j*(h1(n0,1)-h_theta(n0,1)-2*pi/K));% -2,-1
    else
        sola(n0,1)=exp(1j*(h1(n0,1)-h_theta(n0,1)));% 1,2
        solb(n0,1)=exp(1j*(h1(n0,1)-h_theta(n0,1)-2*pi/K));% 1,-1
        solc(n0,1)=exp(1j*(h1(n0,1)-h_theta(n0,1)-2*pi/K));% -2,-1
    end
end
% Compare
x1=[1;sola];x2=[1;solb];x3=[1;solc];
re1=norm(c.'*x1);re2=norm(c.'*x2);re3=norm(c.'*x3);
re=max([re1,re2,re3]);
if re==re1
    x=x1;
elseif re==re2
    x=x2;
else 
    x=x3;
end
end