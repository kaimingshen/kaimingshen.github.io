function [X_RSM] = RMS(loc_BS, loc_IRS, loc_user, P_tx, P_n, N, K,L, num_samples, channel_kind)
for s=1:num_samples
    theta=exp(1j*2*pi/K*(randi(K,[N,1])-ones(N,1)));
    Conf(s,:)=theta;
    Phase=[1;theta];
    for l=1:L
        H = generate_channel(loc_BS, loc_IRS, loc_user, N, P_tx, channel_kind);
        received_power(l, 1) = abs(H.'*Phase)^2 + P_n;
    end
    mean_received_power(s, 1) = mean(received_power);
end
[~, index] = max(mean_received_power);
X_RSM = Conf(index,:);
X_RSM = [1;X_RSM.'];
end