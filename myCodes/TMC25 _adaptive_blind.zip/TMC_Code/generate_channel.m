function [H] = generate_channel(loc_BS, loc_IRS, loc_user, N, P_tx, channel_kind)

pathloss_d = power(10, (P_tx-32.6-36.7*log10(norm(loc_BS-loc_user, 2)))/10);
Rician_factor = 10;
lambda = (3*10^8) / (2.6*10^9);

% Generate Rician fading channel
if channel_kind == 0
    for n=1:N
        pathloss_n = power(10, (P_tx-60-22*log10(norm(loc_BS-loc_IRS(n,:), 2))-22*log10(norm(loc_IRS(n,:)-loc_user, 2)))/10);
        alpha_n = sqrt(Rician_factor/(Rician_factor+1)) * exp(1j*(-2*pi*norm(loc_BS-loc_IRS(n,:),2)/lambda)) + sqrt(1/(Rician_factor+1)) *(randn(1, 1) + 1j*randn(1, 1))/sqrt(2);
        beta_n = sqrt(Rician_factor/(Rician_factor+1)) * exp(1j*(-2*pi*norm(loc_user-loc_IRS(n,:),2)/lambda)) + sqrt(1/(Rician_factor+1)) *(randn(1, 1) + 1j*randn(1, 1))/sqrt(2);
        
        H_r(n, 1) = sqrt(pathloss_n) * alpha_n * beta_n;
    end
    H_d = sqrt(Rician_factor/(Rician_factor+1)) * exp(1j*(-2*pi*norm(loc_BS-loc_user,2)/lambda))+ sqrt(1/(Rician_factor+1))*(randn(1, 1) + 1j*randn(1, 1))/sqrt(2);
    H_d = sqrt(pathloss_d) * H_d;

else
    % Generate Rayleigh fading channel
    for n=1:N
        pathloss_n = power(10, (P_tx-60-22*log10(norm(loc_BS-loc_IRS(n,:), 2))-22*log10(norm(loc_IRS(n,:)-loc_user, 2)))/10);
        alpha_n = sqrt(Rician_factor/(Rician_factor+1)) * exp(1j*(-2*pi*norm(loc_BS-loc_IRS(n,:),2)/lambda)) + sqrt(1/(Rician_factor+1)) *(randn(1, 1) + 1j*randn(1, 1))/sqrt(2);
        beta_n = sqrt(Rician_factor/(Rician_factor+1)) * exp(1j*(-2*pi*norm(loc_user-loc_IRS(n,:),2)/lambda)) + sqrt(1/(Rician_factor+1)) *(randn(1, 1) + 1j*randn(1, 1))/sqrt(2);
        
        H_r(n, 1) = sqrt(pathloss_n) * alpha_n * beta_n;
    end
    H_d = (randn(1, 1) + 1j*randn(1, 1))/sqrt(2);
    H_d = sqrt(pathloss_d) * H_d;
end
H = [H_d;H_r];
end