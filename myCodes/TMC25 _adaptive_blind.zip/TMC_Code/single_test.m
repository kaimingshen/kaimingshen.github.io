function [ACSM_boost, CSM_boost, RSM_boost, CPP_boost, CPP_hat_boost] = single_test(loc_BS, loc_IRS, loc_user, P_tx, P_n_db, N, K, L, num_samples, channel_kind)
P_n = power(10, P_n_db/10);

lambda = (3*10^8) / (2.6*10^9);
for n=1:N
    alpha_n = exp(1j*(-2*pi*norm(loc_BS-loc_IRS(n,:),2)/lambda));
    beta_n = exp(1j*(-2*pi*norm(loc_user-loc_IRS(n,:),2)/lambda));
    H_1_bar(n,1) = alpha_n;
    H_2_bar(n,1) = beta_n;
end
if channel_kind == 0
    H_d_bar = exp(1j*(-2*pi*norm(loc_BS-loc_user,2)/lambda));
else
    H_d_bar = 0;
end
H_r_bar = H_1_bar.*H_2_bar;
H_bar = [H_d_bar;H_r_bar];

if channel_kind == 0
    [~, X_CPP, ~] = zyw_IRS(H_bar, K);
    [H_hat] = ChanEst_DFT_Group(loc_BS, loc_IRS, loc_user, N, K, L, P_tx, P_n_db, channel_kind);
    [~, X_CPP_hat, ~] = zyw_IRS(H_hat, K);
    S_1 = randperm(N, floor(N/3));
    X_ACSM = adaptive_CSM(loc_BS, loc_IRS, loc_user, P_tx, P_n, S_1, N, K, L, num_samples, channel_kind);
    X_CSM = CSM(loc_BS, loc_IRS, loc_user, P_tx, P_n, N, K,L, num_samples, channel_kind);
    X_RSM = RMS(loc_BS, loc_IRS, loc_user, P_tx, P_n, N, K,L, num_samples, channel_kind);
    
    X_list = [X_CPP, X_CPP_hat, X_ACSM, X_RSM, X_CSM];
    boost = get_result(loc_BS, loc_IRS, loc_user, P_tx, N, X_list, P_n, channel_kind);
    CPP_boost = boost(1);
    CPP_hat_boost = boost(2);
    ACSM_boost = boost(3);
    RSM_boost = boost(4);
    CSM_boost = boost(5);
    
elseif channel_kind == 1
    S_1 = randperm(N, floor(N/3));
    [H_hat] = ChanEst_DFT_Group(loc_BS, loc_IRS, loc_user,N, K, L,P_tx, P_n_db, channel_kind);
    X_ACPP = adaptive_CPP(S_1, H_r_bar, N, K);
    X_ACPP_hat = adaptive_CPP(S_1, H_hat(2:N+1), N, K);
    X_CSM = CSM(loc_BS, loc_IRS, loc_user, P_tx, P_n, N, K, L, num_samples, channel_kind);
    X_ACSM = adaptive_CSM(loc_BS, loc_IRS, loc_user, P_tx, P_n, S_1, N, K,L, num_samples, channel_kind);
    X_RSM = RMS(loc_BS, loc_IRS, loc_user, P_tx, P_n, N, K, L, num_samples, channel_kind);
    
    X_list = [X_ACPP, X_ACPP_hat, X_ACSM, X_RSM, X_CSM];
    boost = get_result(loc_BS, loc_IRS, loc_user, P_tx, N, X_list, P_n, channel_kind);
    CPP_boost = boost(1);
    CPP_hat_boost = boost(2);
    ACSM_boost = boost(3);
    RSM_boost = boost(4);
    CSM_boost = boost(5);

else
    S_1 = randperm(N, floor(N/3));
    [H_hat] = ChanEst_DFT_Group(loc_BS, loc_IRS, loc_user,N, K, L,P_tx, P_n_db, channel_kind);
    X_ACPP = adaptive_CPP(S_1, H_r_bar, N, K);
    X_ACPP_hat = adaptive_CPP(S_1, H_hat(2:N+1), N, K);
    X_CSM = CSM(loc_BS, loc_IRS, loc_user, P_tx, P_n, N, K, L, num_samples, channel_kind);
    X_ACSM = adaptive_CSM(loc_BS, loc_IRS, loc_user, P_tx, P_n, S_1, N, K,L, num_samples, channel_kind);
    X_RSM = RMS(loc_BS, loc_IRS, loc_user, P_tx, P_n, N, K, L, num_samples, channel_kind);
    
    X_list = [X_ACPP, X_ACPP_hat, X_ACSM, X_RSM, X_CSM];
    boost = get_result(loc_BS, loc_IRS, loc_user, P_tx, N, X_list, P_n, channel_kind);
    CPP_boost = 0;
    CPP_hat_boost = boost(2);
    ACSM_boost = boost(3);
    RSM_boost = boost(4);
    CSM_boost = boost(5);
end
end