clear;
loc_BS = [50,-200, 20];
loc_top_right_IRS = [-2, -6, 1];

P_tx = 20;
P_n_db = -90;
P_n = power(10, P_n_db/10);
N = 100;
N_h = 10;
N_w = N/N_h;
num_samples = 1000;
K = 3;
L = 1;
channel_kind = 1; %0:all channels are Rician; 1:direct channel is Rayleigh;

loc_IRS = zeros(N, 3);
counter_w = 0;
counter_h = 0;
for n=1:N
    loc_IRS(n,:) = loc_top_right_IRS+[0, counter_w*0.1, -counter_h*0.1];
    counter_w=counter_w+1;
    if  counter_w == N_w
        counter_h=counter_h+1;
        counter_w = 0;
    end
end

parfor_progress(1000);
parfor i=1:1000
loc_user_x = unifrnd(0, 2);
loc_user_y = unifrnd(0, 2);
loc_user = [loc_user_x, loc_user_y, 0];
[GCSM_boost(i, 1), CSM_boost(i, 1), RMS_boost(i, 1), CPP_boost(i, 1), CPP_hat_boost(i, 1)] = single_test(loc_BS, loc_IRS, loc_user, P_tx, P_n_db, N, K,L, num_samples, channel_kind);
parfor_progress; 
end
parfor_progress(0);
