function [h_hat] = ChanEst_DFT_Group(loc_BS, loc_IRS, loc_user,N, K, L, P_tx, P_n_db, channel_kind)    
omega = [0.5,1,1.5,2];
D_bar = mod((angle(dftmtx(N+1))/pi),2);
for m1 = 1:N+1
    for m2 = 1:N+1
        dis = 100;
        for k = 1:K
            if abs(D_bar(m1,m2)-omega(k))<dis
                dis = abs(D_bar(m1,m2)-omega(k));
                D(m1,m2) = exp(1i*omega(k)*pi);
            end
        end
    end
end
for i=1:N+1
for l=1:L
    H = generate_channel(loc_BS, loc_IRS, loc_user, N, P_tx, channel_kind);
    y_temp(l) = D(i,:)*H+(10^(P_n_db/20))/sqrt(2)*(randn+1j*randn);
end
y(i, 1) = mean(y_temp);
end
h_hat = inv(D)*y;