function [xcm, xcm_ind, Jnk]=CondMean(S,Hd,K,state, N_start, N_end)
[T,N]=size(Hd);
% T is the number of trails, N is the number of elements
% Obatin Omega_k from the Hd
Hd_K = zeros(T, N);
for t0=1:T
    for n0=N_start:N_end
        temp=angle(Hd(t0,n0));
        if temp<0
            temp=temp+2*pi;
        end
        Hd_K(t0,n0)=fix(temp/(2*pi/K));
    end
end
% Calcualte the conditional mean for every element
% the mean value is stored in the matrix Jnk
Jnk = zeros(N, K);
for n0=N_start:N_end
    for k0=1:K
        mark=find(Hd_K(:,n0)==k0-1);
        if isempty(mark)
            Jnk(n0,k0) = 0;
        else
            Jnk(n0,k0)=sum(S(mark,1))/length(find(Hd_K(:,n0)==k0-1));
        end
    end
end
%% Conditional mean method
xcm = zeros(N, 1);
xcm_ind = zeros(N, 1);
if state == 0
for n0=N_start:N_end
    [~,index]=max(Jnk(n0,:));
    xcm_ind(n0) = index;
    xcm(n0,1)=exp(1j*2*pi/K*(index-1));
end
xcm=[1;xcm];
else
for n0=N_start:N_end
    [~,index]=min(Jnk(n0,:));
    xcm_ind(n0) = index;
    xcm(n0,1)=exp(1j*2*pi/K*(index-1));
end
xcm=[1;xcm]; 
end