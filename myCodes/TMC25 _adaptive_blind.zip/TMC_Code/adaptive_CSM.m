function [X_ACSM] = adaptive_CSM(loc_BS, loc_IRS, loc_user, P_tx, P_n, S_1, N, K, L, num_samples, channel_kind)
    % Stage 1 of ACSM
    S = 1:N;
    X_temp = zeros(N, 1);
    S_1_prime = setdiff(S, S_1);
    
    X_RSM = ones(1, N+1);
    X_temp(S_1) = X_RSM(S_1);
    
    T_1 = floor(num_samples/3);
    for s=1:T_1
        theta=exp(1j*2*pi/K*(randi(K,[N,1])-ones(N,1)));
        theta(S_1) = X_temp(S_1);
        Conf(s,:)=theta;
        Phase=[1;theta];
        for l=1:L
            H = generate_channel(loc_BS, loc_IRS, loc_user, N, P_tx, channel_kind);
            received_power(l, 1) = abs(H.'*Phase)^2 + P_n;
        end
        mean_received_power(s, 1) = mean(received_power);
    end
    [X_CSM_1,X_CSM_1_ind, Jnk] = CondMean(mean_received_power, Conf, K, 0, 1, N);
    X_temp(S_1_prime) = X_CSM_1(S_1_prime+1);

    % Stage 2 of ACSM
    S_2 = [];S_3 = [];
    for i = S_1_prime
        index_temp = X_CSM_1_ind(i);
        index_left = index_temp + 1;
        if mod(index_left, K) == 0
            index_left = K;
        else
            index_left = mod(index_left, K);
        end
        index_right = index_temp - 1;
        if mod(index_right, K) == 0
            index_right = K;
        else
            index_right = mod(index_right, K);
        end
        if Jnk(i, index_left) >= Jnk(i, index_right)
            S_3 = [S_3, i];
        else
            S_2 = [S_2, i];
        end
    end
    
    T_2 = num_samples - T_1;
    if length(S_2) > length(S_3)
        for s=1:T_2
            theta=exp(1j*2*pi/K*(randi(K,[N,1])-ones(N,1)));
            theta(S_2) = X_temp(S_2);
            Conf(s,:)=theta;
            Phase=[1;theta];
            for l=1:L
                H = generate_channel(loc_BS, loc_IRS, loc_user, N, P_tx, channel_kind);
                received_power(l, 1) = abs(H.'*Phase)^2 + P_n;
            end
            mean_received_power(s, 1) = mean(received_power);
        end
        [X_CSM_2,~, ~] = CondMean(mean_received_power, Conf, K, 0, 1, N);
        X_temp(setdiff(S, S_2)) = X_CSM_2(setdiff(S, S_2));
        X_ACSM = [1;X_temp];
    else
        for s=1:T_2
            theta=exp(1j*2*pi/K*(randi(K,[N,1])-ones(N,1)));
            theta(S_3) = X_temp(S_3);
            Conf(s,:)=theta;
            Phase=[1;theta];
            for l=1:L
                H = generate_channel(loc_BS, loc_IRS, loc_user, N, P_tx, channel_kind);
                received_power(l, 1) = abs(H.'*Phase)^2 + P_n;
            end
            mean_received_power(s, 1) = mean(received_power);
        end
        [X_CSM_2,~, ~] = CondMean(mean_received_power, Conf, K, 0, 1, N);
        X_temp(setdiff(S, S_3)) = X_CSM_2(setdiff(S, S_3)+1);
        X_ACSM = [1;X_temp];
    end
end