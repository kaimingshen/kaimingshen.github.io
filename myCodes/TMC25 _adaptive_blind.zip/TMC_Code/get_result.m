function [boost] = get_result(loc_BS, loc_IRS, loc_user, P_tx, N, X_list, P_n, channel_kind)
    [~, col] = size(X_list);
    num_samples = 1000;
    for i=1:num_samples
        [H] = generate_channel(loc_BS, loc_IRS, loc_user, N, P_tx, channel_kind);
        for c=1:col
%             SNR(i, c) = abs(H.'*X_list(:, c))^2/P_n;
            Rate(i, c) = log2(1+abs(H.'*X_list(:, c))^2/P_n);
        end
%         SNR_noirs(i, 1) = abs(H(1))^2/P_n;
        Rate_noirs(i, 1) = log2(1+abs(H(1))^2/P_n);
    end
%     Rate_noirs_mean = mean(Rate_noirs);
    boost = mean(Rate, 1);
%     SNR_noirs_mean = mean(SNR_noirs);
%     boost = mean(SNR, 1)/SNR_noirs_mean;
end