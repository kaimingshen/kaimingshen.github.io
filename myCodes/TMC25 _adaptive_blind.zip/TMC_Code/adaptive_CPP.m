function [X_ACPP] = adaptive_CPP(S_1, H, N, K)
    S = 1:N;
    X_temp = zeros(N, 1);
    
    S_1_prime = setdiff(S, S_1);
    
    % Stage 1 of ACPP
    h_1 = sum(H(S_1));
    [~,X_stage1,~] = zyw_IRS([h_1;H], K);
    X_temp(S_1_prime) = X_stage1(S_1_prime+1);
    h_23 = H.*X_temp;
    
    h_1_angle = angle(h_1);
    if h_1_angle <0
        h_1_angle = h_1_angle+2*pi;
    end
    h_23_angle = zeros(N, 1);
    for n0=1:N
        temp=angle(h_23(n0));
        if temp<0
            temp=temp+2*pi;
        end
        h_23_angle(n0)=temp;
    end
    
    % Stage 2 of ACPP
    S_2 = [];
    S_3 = [];
    for i=1:N
        if (h_23(i) ~= 0) && (h_23_angle(i)>=h_1_angle)
            S_2 = [S_2, i];
        elseif (h_23(i) ~= 0) && (h_23_angle(i)<h_1_angle)
            S_3 = [S_3, i];
        end
    end
    if length(S_2) > length(S_3)
        h_2 = sum(h_23(S_2));
        [~, X_stege_2, ~] = zyw_IRS([h_2;H], K);
        X_temp(union(S_1, S_3)) = X_stege_2(union(S_1, S_3)+1);
        X_ACPP = [1;X_temp];
    else
        h_2 = sum(h_23(S_3));
        [~, X_stege_2, ~] = zyw_IRS([h_2;H], K);
        X_temp(union(S_1, S_2)) = X_stege_2(union(S_1, S_2)+1);
        X_ACPP = [1;X_temp];
    end
end