% clc; clear; close all;

%% ========== 替换成你自己的数据 ==========

% 横轴：迭代次数（0:1:100）
x = 0:1:50;

% 原始5条曲线（示例数据，可替换）
y_wmmse  = ER_fp(1:51);    
y_alg1   = ER_fast(1:51);   
y_alg2   = ER_momentum(1:51);   
y_rlpd   = iter_results_fp(1:51);   
y_swmmse = iter_results_fast(1:51);     

% ===== 新增两条曲线（你可替换为真实数据）=====
y_alg3   = iter_results_momentum(1:51);   % Algorithm 3


%% === 只取 10 个点显示 marker ===
marker_idx = 1:2:51;

%% ========= 画图 =========
figure('Position',[300 200 560 420]);
hold on; grid on;

% WMMSE
plot(x, y_wmmse,'--+','Color',[0.8500 0.3250 0.0980], ...
     'LineWidth',1.5,'MarkerSize',6,'MarkerIndices',marker_idx);

% Algorithm 1
plot(x, y_alg1,'-s','Color',[0.4940 0.1840 0.5560], ...
     'LineWidth',1.5,'MarkerSize',6,'MarkerFaceColor','none', ...
     'MarkerIndices',marker_idx);

% Algorithm 2
plot(x, y_alg2,'-s','Color',[0 0.4470 0.7410], ...
     'LineWidth',1.5,'MarkerSize',6,'MarkerFaceColor','none', ...
     'MarkerIndices',marker_idx);

% RLPD
plot(x, y_rlpd,':d','Color',[0.4660 0.6740 0.1880], ...
     'LineWidth',1.5,'MarkerSize',6,'MarkerFaceColor','none', ...
     'MarkerIndices',marker_idx);

% SWMMSE
plot(x, y_swmmse,'--o','Color',[0.9290 0.6940 0.1250], ...
     'LineWidth',1.5,'MarkerSize',6,'MarkerFaceColor','none', ...
     'MarkerIndices',marker_idx);

% ===== 新增：Algorithm 3 =====
plot(x, y_alg3,'-^','Color',[0.3010 0.7450 0.9330], ...
     'LineWidth',1.5,'MarkerSize',6,'MarkerFaceColor','none', ...
     'MarkerIndices',marker_idx);


%% ========== 坐标轴 ==========
set(gca,'FontSize',12,'FontName','Times New Roman');
set(gca,'Box','on');

xlabel('Iteration Number', ...
       'FontSize',14,'FontWeight','normal','Interpreter','latex');

ylabel('Average Sum Rate (bits/s/Hz)', ...
       'FontSize',14,'FontWeight','normal','Interpreter','latex');

xlim([0 50]);
ylim([0 160]);


%% ========== 图例 ==========
legend({'Algorithm 1','Algorithm 2','Algorithm 2 with momentum','Lower bound with Alg. 1',...
        'Lower bound with Alg. 2','Lower bound with Alg. 2 & momentum'}, ...
       'FontSize',12,'FontName','Times New Roman', ...
       'Location','southeast','EdgeColor',[0.3 0.3 0.3], ...
       'Interpreter','latex');


%% ========== 网格 ==========
ax = gca;
ax.GridAlpha = 0.25;
ax.XMinorGrid = 'off';
ax.YMinorGrid = 'off';
ax.XMinorTick = 'off';
ax.YMinorTick = 'off';

hold off;
