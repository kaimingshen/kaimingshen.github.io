% clc; clear; close all;
%% ========== 替换成你自己的数据 (8 条曲线) ==========
% 横轴：迭代次数（-7:-0.25:-11）
% *** 1. 90 km/h 组数据 (假设性能略低或在Y轴较低位置) ***
% 请用您的实际数据替换这些占位数据！
load("K16_60_conver.mat")
y_wmmse_90 = ER4;    
y_alg1_90  = ER2;   
y_alg2_90  = ER1;   
y_rlpd_90  = ER7;   
% *** 2. 120 km/h 组数据 (假设性能略高或在Y轴较高位置) ***
% 请用您的实际数据替换这些占位数据！
load("K16_90_conver.mat")
y_wmmse_120 = ER4;    
y_alg1_120  = ER2;   
y_alg2_120  = ER1;   
y_rlpd_120  = ER7;   
% !!! 调整 Y 轴范围以容纳所有数据 !!!
y_lim_setting = [0 300];
%% ========= 画图：使用颜色区分算法，所有速度组使用相同的样式 =========
figure('Position',[300 200 560 420]);
hold on; grid on;
% --- 定义颜色和样式（区分算法）---
COLOR_WMMSE = [0.8500 0.3250 0.0980]; STYLE_WMMSE = '--+'; 
COLOR_ALG1  = [0 0.4470 0.7410];     STYLE_ALG1  = '-s';
COLOR_ALG2  = [0.4660 0.6740 0.1880]; STYLE_ALG2  = ':d';
COLOR_RLPD  = [0.9290 0.6940 0.1250]; STYLE_RLPD  = '--o';
x = -7:-0.25:-11; % 17个点
marker_idx = 1:2:17; 
% --- 绘制 90 km/h 组 (空心 Marker) ---
% WMMSE @ 90km/h
plot(x, y_wmmse_90, STYLE_WMMSE, 'Color', COLOR_WMMSE, ...
     'LineWidth',1.5,'MarkerSize',6,'MarkerIndices',marker_idx, ...
     'MarkerFaceColor','none');
% Algorithm 1 @ 90km/h
plot(x, y_alg1_90, STYLE_ALG1, 'Color', COLOR_ALG1, ...
     'LineWidth',1.5,'MarkerSize',6,'MarkerFaceColor','none', ...
     'MarkerIndices',marker_idx);
% Algorithm 2 @ 90km/h
plot(x, y_alg2_90, STYLE_ALG2, 'Color', COLOR_ALG2, ...
     'LineWidth',1.5,'MarkerSize',6,'MarkerFaceColor','none', ...
     'MarkerIndices',marker_idx);
% RLPD @ 90km/h
plot(x, y_rlpd_90, STYLE_RLPD, 'Color', COLOR_RLPD, ...
     'LineWidth',1.5,'MarkerSize',6,'MarkerFaceColor','none', ...
     'MarkerIndices',marker_idx);
% --- 绘制 120 km/h 组 (空心 Marker，与 90km/h 组保持一致) ---
% WMMSE @ 120km/h
plot(x, y_wmmse_120, STYLE_WMMSE, 'Color', COLOR_WMMSE, ...
     'LineWidth',1.5,'MarkerSize',6,'MarkerIndices',marker_idx, ...
     'MarkerFaceColor','none'); 
% Algorithm 1 @ 120km/h
plot(x, y_alg1_120, STYLE_ALG1, 'Color', COLOR_ALG1, ...
     'LineWidth',1.5,'MarkerSize',6,'MarkerFaceColor','none', ... 
     'MarkerIndices',marker_idx);
% Algorithm 2 @ 120km/h
plot(x, y_alg2_120, STYLE_ALG2, 'Color', COLOR_ALG2, ...
     'LineWidth',1.5,'MarkerSize',6,'MarkerFaceColor','none', ... 
     'MarkerIndices',marker_idx);
% RLPD @ 120km/h
plot(x, y_rlpd_120, STYLE_RLPD, 'Color', COLOR_RLPD, ...
     'LineWidth',1.5,'MarkerSize',6,'MarkerFaceColor','none', ... 
     'MarkerIndices',marker_idx);
     
%% ========== 坐标轴 ==========
set(gca,'FontSize',12,'FontName','Times New Roman');
set(gca,'Box','on');
xlabel('$$\sigma^2$$ (dBm)', ...
       'FontSize',14,'FontWeight','normal','Interpreter','latex');
ylabel('Average Sum Rate (bits/s/Hz)', ...
       'FontSize',14,'FontWeight','normal','Interpreter','latex');
xlim([-11 -7]);
ylim(y_lim_setting); 

%% ========== 标注：圆圈和文本 (突出集中区域) ==========
% 计算 90km/h 组和 120km/h 组的大致 Y 轴中心点
y_mean_90 = mean([y_wmmse_90, y_alg1_90, y_alg2_90, y_rlpd_90], 'all');
y_mean_120 = mean([y_wmmse_120, y_alg1_120, y_alg2_120, y_rlpd_120], 'all');

% 设置圆圈的位置和大小 (使用归一化坐标)
x_circle_center_norm = 0.5;   % X 轴中心
circle_size_norm = 0.1;       % 圆圈的直径/边长
circle_line_width = 1.0;      % **** 调整线条粗细为 1.0 ****

x_lim = xlim;
y_lim = ylim;

% 1. 标注 90km/h 区域
y_circle_90_norm = (y_mean_90 - y_lim_setting(1)) / (y_lim_setting(2) - y_lim_setting(1));

% 绘制黑色的正圆
annotation('ellipse', ...
           [x_circle_center_norm - circle_size_norm/2, ... 
            y_circle_90_norm - circle_size_norm/2, ...    
            circle_size_norm, ...                         
            circle_size_norm], ...                        
           'Color', 'k', 'LineWidth', circle_line_width, 'LineStyle', '-');

% 添加文本箭头
x_arrow_start_norm = 0.75; % 文本标签的 X 位置 (在右侧)
annotation('textarrow', ...
           [x_arrow_start_norm, x_circle_center_norm + circle_size_norm/2], ... 
           [y_circle_90_norm + circle_size_norm/2, y_circle_90_norm], ...      
           'String', '60 km/h', ...
           'FontSize', 12, 'Color', 'k', ...
           'FontName', 'Times New Roman', ... 
           'FontWeight', 'bold', 'HeadStyle', 'vback2', 'LineWidth', 1);

% 2. 标注 120km/h 区域
y_circle_120_norm = (y_mean_120 - y_lim_setting(1)) / (y_lim_setting(2) - y_lim_setting(1));

% 绘制黑色的正圆
annotation('ellipse', ...
           [x_circle_center_norm - circle_size_norm/2, ... 
            y_circle_120_norm - circle_size_norm/2, ...   
            circle_size_norm, ...                        
            circle_size_norm], ...                       
           'Color', 'k', 'LineWidth', circle_line_width, 'LineStyle', '-');

% 添加文本箭头
annotation('textarrow', ...
           [x_arrow_start_norm, x_circle_center_norm + circle_size_norm/2], ... 
           [y_circle_120_norm + circle_size_norm/2, y_circle_120_norm], ...     
           'String', '90 km/h', ...
           'FontSize', 12, 'Color', 'k', ...
           'FontName', 'Times New Roman', ... 
           'FontWeight', 'bold', 'HeadStyle', 'vback2', 'LineWidth', 1);

%% ========== 图例 (只包含算法名称) ==========
legend_h = gobjects(4,1); % 创建用于图例的句柄数组
legend_h(1) = plot(NaN, NaN, STYLE_WMMSE, 'Color', COLOR_WMMSE, 'LineWidth', 1.5, 'MarkerFaceColor', 'none');
legend_h(2) = plot(NaN, NaN, STYLE_ALG1, 'Color', COLOR_ALG1, 'LineWidth', 1.5, 'MarkerFaceColor', 'none');
legend_h(3) = plot(NaN, NaN, STYLE_ALG2, 'Color', COLOR_ALG2, 'LineWidth', 1.5, 'MarkerFaceColor', 'none');
legend_h(4) = plot(NaN, NaN, STYLE_RLPD, 'Color', COLOR_RLPD, 'LineWidth', 1.5, 'MarkerFaceColor', 'none');

% **** 根据您的要求修改图例名称和顺序 ****
legend_names = {'WMMSE', 'Algorithm 1 (or 2)', 'RLPD', 'SWMMSE'};

% 注意：如果RLPD对应的线型是--o (legend_h(4))，要将其名称放在第三个位置，需要调整传入 legend 函数的数组顺序。
% 为了最简洁地实现名称修改，我们直接修改 legend_names 数组，并按原句柄顺序传入：
legend(legend_h, ...
       {'WMMSE', 'Algorithm 1 (or 2)', 'RLPD', 'SWMMSE'}, ... % 假定您希望的标签顺序
       'FontSize',12,'FontName','Times New Roman', ...
       'Location','northwest','EdgeColor',[0.3 0.3 0.3], ...
       'Interpreter','latex');
       
%% ========== 网格/坐标轴细节调整 ==========
ax = gca;
ax.GridAlpha = 0.25;
% 1. 确保横轴方向为反向
ax.XDir = 'reverse';

% 2. 定义新的刻度位置 (原 X 轴值，间隔 0.5)
original_x_ticks = -11 : 0.5 : -7; 
ax.XTick = original_x_ticks;

% 3. 定义新的刻度标签 (将原 X 轴值乘以 10，然后转换为字符串)
new_x_labels_numeric = original_x_ticks * 10;
new_x_labels_string = arrayfun(@num2str, new_x_labels_numeric, 'UniformOutput', false);

ax.XTickLabel = new_x_labels_string; 

hold off;