
% 1. 生成数据
[x, y] = meshgrid(0:0.01:1, -110:2.5:-70);

% 红色曲面 (上方)
z_red = gap1;

% 蓝色曲面 (中间)
z_blue = gap2;

% 绿色曲面 (穿过0平面)
z_green = gap3; 

% =========================================================
% 核心步骤 A: 拆分绿色曲面数据
% =========================================================
z_green_pos = z_green;
z_green_pos(z_green < 0) = NaN; % 过滤掉小于0的部分

z_green_neg = z_green;
z_green_neg(z_green >= 0) = NaN; % 过滤掉大于0的部分

% =========================================================
% 开始绘图
% =========================================================
figure('Color', 'w', 'Position', [100, 100, 900, 700]);
hold on; grid on; box on;

% 2. 绘制红色和蓝色曲面 (使用 surf)
% FaceAlpha 设置透明度，防止遮挡
surf(z_red, 'FaceColor', 'r', 'EdgeColor', [0.8 0 0], 'FaceAlpha', 0.1);
surf(z_blue, 'FaceColor', 'b', 'EdgeColor', [0 0 0.8], 'FaceAlpha', 0.1);

% 3. 绘制双色绿色曲面
% 绿色大于0部分：深绿色
surf(z_green_pos, 'FaceColor', [0, 0.6, 0], ...
    'EdgeColor', [0, 0.4, 0], 'FaceAlpha', 0.7);

% 绿色小于0部分：浅绿色 (荧光绿)
surf(z_green_neg, 'FaceColor', [0.6, 0.9, 0.4], ...
    'EdgeColor', [0.4, 0.6, 0.2], 'FaceAlpha', 0.7);

% =========================================================
% 核心步骤 B: 在 Z=0 处手动绘制坐标轴
% =========================================================
% 获取当前绘图范围
x_lim = [1 17];
y_lim = [-110 -70];

% 1. 画一个半透明平面表示 Z=0 (选做，为了视觉更清晰)
patch([x_lim(1) x_lim(2) x_lim(2) x_lim(1)], ...
      [y_lim(1) y_lim(1) y_lim(2) y_lim(2)], ...
      [0 0 0 0], 'k', 'FaceAlpha', 0.05, 'EdgeColor', 'none');

% 2. 画 X轴 和 Y轴 (粗黑线)
% 注意：这里把轴画在 Box 的边缘，但高度提升到了 Z=0
plot3(x_lim, [y_lim(1) y_lim(1)], [0 0], 'k-', 'LineWidth', 2); % 模拟X轴
plot3([x_lim(1) x_lim(1)], y_lim, [0 0], 'k-', 'LineWidth', 2); % 模拟Y轴

% 3. 画 Z=0 的网格辅助线 (虚线)
plot3(x_lim, [y_lim(2) y_lim(2)], [0 0], 'k--', 'LineWidth', 1); 
plot3([x_lim(2) x_lim(2)], y_lim, [0 0], 'k--', 'LineWidth', 1);

% =========================================================
% 装饰与光照
% =========================================================
view(-45, 20); % 调整视角
xlabel('\rho_{jk}');
ylabel('\sigma^2 (dBm)');
zlabel('Error of Approximations');

zlim([-8 16]); % 限制Z轴范围

% 添加光照让 surf 更有立体感
light('Position',[-1 -1 1],'Style','infinite');
lighting gouraud; % 让曲面光滑

% 图例
legend('Red Surface', 'Blue Surface', ...
       'Green (Value > 0)', 'Green (Value < 0)', ...
       'Location', 'best');

hold off;
