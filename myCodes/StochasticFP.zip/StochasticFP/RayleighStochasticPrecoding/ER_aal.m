function [obj, R_lb, int] = ER_aal(H_hat,M,beta,P,sigma,w)

[Ux_N, Bx_N, K, Bs,~] = size(H_hat);
H_bar = zeros(Ux_N, Bx_N, K, Bs, Bs);
for b = 1:Bs
    for k = 1:K
        for m = 1:Bs
            H_bar(:,:,k,b,m) = beta(k,b)*H_hat(:,:,k,b,m);
        end
    end
end

R_lb = zeros(K,Bs);

R = zeros(Ux_N,Ux_N, K, Bs);
A = zeros(Bx_N,Bx_N, K, Bs);
Ga = zeros(Bx_N,Bx_N, K, Bs);
Ga_td = zeros(Ux_N,Ux_N, K, Bs);
for b = 1:Bs
    for k = 1:K
        %% calculate R
        R(:,:,k,b) = sigma^2*eye(Ux_N);
        for l = 1:K
            if l ~= k 
                R(:,:,k,b) = R(:,:,k,b)+EHxxH(H_hat(:,:,k,b,b),M(:,:,k,b,b),P(:,:,l,b),beta(k,b));
            end
        end
        invR = pinv(R(:,:,k,b));

        %% calculate A
        A(:,:,k,b) = EHCH(H_hat(:,:,k,b,b)',M(:,:,k,b,b)',invR,beta(k,b));

        %% calculate Gamma and Gamma_td
        R_ms = invR^(1/2);
        G = inv(eye(Ux_N)+P(:,:,k,b)'*P(:,:,k,b));
        G_td = inv(eye(Ux_N)+invR);
        for j = 1:2
            eta_td_G_td = Eta_func(M(:,:,k,b)',R_ms*G_td*R_ms,beta(k,b));
            eta_G = Eta_func(M(:,:,k,b),P(:,:,k,b)*G*P(:,:,k,b)',beta(k,b));
            Phi = eye(Ux_N)+P(:,:,k,b)'*eta_td_G_td*P(:,:,k,b);
            Phi_td = eye(Ux_N)+R_ms*eta_G*R_ms;
            Ga(:,:,k,b)=eta_td_G_td+H_bar(:,:,k,b,b)'*R_ms*pinv(Phi_td)*R_ms*H_bar(:,:,k,b,b);
            Ga_td(:,:,k,b)=eta_G+H_bar(:,:,k,b,b)*P(:,:,k,b)*pinv(Phi)*P(:,:,k,b)'*H_bar(:,:,k,b,b)';
            G = pinv(eye(Ux_N)+P(:,:,k,b)'*Ga(:,:,k,b)*P(:,:,k,b));
            G_td = pinv(eye(Ux_N)+R_ms*Ga_td(:,:,k,b)*R_ms);
        end
        R_lb(k,b) = log2(real(det(eye(Bx_N)+Ga(:,:,k,b)*P(:,:,k,b)*P(:,:,k,b)')))+log2(real(det(Phi_td)))-trace(real(eta_G*R_ms*G_td*R_ms));
    end
end

obj = sum(sum(R_lb.*w));
end