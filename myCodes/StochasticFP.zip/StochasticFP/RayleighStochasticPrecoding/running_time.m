mt = mt+1;

for i = 100:-1:2
    time_aal(i)=time_aal(i)-time_aal(i-1);
    time_fast(i)=time_fast(i)-time_fast(i-1);
    time_fp(i)=time_fp(i)-time_fp(i-1);
    time_SWMMSE(i)=time_SWMMSE(i)-time_SWMMSE(i-1);
    timeWMMSE(i)=timeWMMSE(i)-timeWMMSE(i-1);
end

time_mt_aal(mt) = mean(time_aal(2:100));
time_mt_fast(mt) = mean(time_fast(2:61));
time_mt_fp(mt) = mean(time_fp(2:100));
time_mt_SWMMSE(mt) = mean(time_SWMMSE(2:100));
time_mt_WMMSE(mt) = mean(timeWMMSE(2:100));