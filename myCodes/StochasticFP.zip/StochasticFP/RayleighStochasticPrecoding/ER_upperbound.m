function [EsumR, ER, ER_ub] = ER_upperbound(H_hat,M,beta,P,sigma,w)
[Ux_N, Bx_N, K, Bs,~] = size(H_hat);
H = zeros(Ux_N, Bx_N, K, Bs, Bs);

N_samples = 3000;

ER = zeros(K,Bs);
ESNR = zeros(Ux_N,Ux_N,K,Bs);
parfor s = 1:N_samples
    [R,SNR] = R_downlink(H, H_hat,M,beta,P,sigma,Ux_N, Bx_N, K, Bs);
    ER = ER + R;
    ESNR = ESNR + SNR;
end
ER = ER/N_samples;
ESNR = ESNR/N_samples;
ER_ub = 0;
for b = 1:Bs
    for k = 1:K
        ER_ub = ER_ub + w(k,b)*real(log2(det(eye(Ux_N)+ESNR(:,:,k,b))));
    end
end
EsumR = sum(sum(ER.*w));
end

function [R,SNR] = R_downlink(H, H_hat,M,beta,P,sigma,Ux_N, Bx_N, K, Bs)
for b = 1:Bs
    for k = 1:K
        for m = 1:Bs
            H(:,:,k,b,m) = beta(k,b)*H_hat(:,:,k,b,m) + sqrt(1-beta(k,b)^2)*(M(:,:,k,b,m).*(randn(Ux_N,Bx_N)/sqrt(2)+randn(Ux_N,Bx_N)*1i/sqrt(2)));
        end
    end
end
R = zeros(K,Bs);
SNR = zeros(Ux_N, Ux_N, K, Bs);
for b = 1:Bs
    for k = 1:K
        int = zeros(Ux_N, Ux_N);
        for m = 1:Bs
            for l = 1:K
                if l~=k || m~=b
                    Hp = H(:,:,k,b,m)*P(:,:,l,m);
                    int = int + Hp*Hp';
                end
            end
        end
        Hp = H(:,:,k,b,b)*P(:,:,k,b);
        SNR(:,:,k,b) = Hp'/(sigma^2*eye(Ux_N)+int)*Hp;
        R(k,b) = real(log2(det(eye(Ux_N)+SNR(:,:,k,b))));
    end
end
end