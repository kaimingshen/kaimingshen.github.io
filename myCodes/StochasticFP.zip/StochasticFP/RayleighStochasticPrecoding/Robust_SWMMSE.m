function [iter_results,time,ER_results,P_star] = Robust_SWMMSE(H_hat,M,P,beta,sigma,w,Pmax)
%UNTITLED5 此处显示有关此函数的摘要
%   P is the beamformer
[Ux_N, Bx_N, K, Bs,~] = size(H_hat);
H_bar = zeros(Ux_N, Bx_N, K, Bs, Bs);
for b = 1:Bs
    for k = 1:K
        for m = 1:Bs
            H_bar(:,:,k,b,m) = beta(k,b)*H_hat(:,:,k,b,m);
        end
    end
end

lam = 0.98;
be = 10e-20;

% initialize U


MaxIter = 51;
iter_results = zeros(MaxIter,1);
ER_results = zeros(MaxIter,1);
% [iter_results(1), ~, ~] = obj_func_downlink(H_hat,H_bar,M,ones(K,1),P,sigma,w);
[ER_results(1), ~] = ER_downlink(H_hat,M,beta,P,sigma,w);
time = zeros(MaxIter,1);
eps = 1e-6;

U_k = zeros(Ux_N,Ux_N,K,Bs);
W = zeros(Ux_N,Ux_N,K,Bs);
A = zeros(Bx_N,Bx_N,Bs);
B = zeros(Bx_N,Ux_N,K,Bs);

for iter = 2:MaxIter
%     if iter>10 && abs(iter_results(iter-1)-iter_results(iter-2))/iter_results(iter-2)<eps
%         break
%     end
    tic
    %% channel generation
    H_r = zeros(Ux_N, Bx_N, K, Bs, Bs);
    for k = 1:K
        for b = 1:Bs
            for m = 1:Bs
                H_r(:,:,k,b,m) = H_bar(:,:,k,b,m) + sqrt(1-beta(k)^2)*(M(:,:,k,b,m).*(randn(Ux_N,Bx_N)/sqrt(2)+randn(Ux_N,Bx_N)*1j/sqrt(2)));
            end
        end
    end
        
    %% update U
    dom = zeros(Ux_N,Ux_N, K);
    for b = 1:Bs
        for k = 1:K
            for m = 1:Bs
                for l = 1:K
                    tmp = H_r(:,:,k,b,m)*P(:,:,l,m);
                    dom(:,:,k) = dom(:,:,k)+tmp*tmp';
                end
            end
            U_k(:,:,k,b) = pinv(dom(:,:,k)+sigma^2*eye(Ux_N))*H_r(:,:,k,b,b)*P(:,:,k,b);
        end
        %% update W
        for k = 1:K
            W(:,:,k,b) = pinv(eye(Ux_N)-U_k(:,:,k,b)'*H_r(:,:,k,b,b)*P(:,:,k,b));
        end
    end

    %% update A B
    for b = 1:Bs
        A(:,:,b) = lam*A(:,:,b) + be*eye(Bx_N);
        for m = 1:Bs
            for l = 1:K
                A(:,:,b) = A(:,:,b) + H_r(:,:,l,m,b)'*U_k(:,:,l,m)*W(:,:,l,m)*U_k(:,:,l,m)'*H_r(:,:,l,m,b);
            end
        end
        for k = 1:K
            B(:,:,k,b) = lam*B(:,:,k,b) + be*P(:,:,k,b) + H_r(:,:,k,b,b)'*U_k(:,:,k,b)*W(:,:,k,b);
        end
        P(:,:,:,b) = updateP_SWMMSE(A(:,:,b),B(:,:,:,b),Pmax);
    end

    t_run = toc;
    time(iter) = time(iter-1)+t_run;
%     if time(iter)>0.5 && iter>2
%         break;
%     end
    P_star = P;

    % [iter_results(iter), R_lb, ~] = obj_func_downlink(H_hat,H_bar,M,ones(K,1),P,sigma,w);
    [ER_results(iter), ~] = ER_downlink(H_hat,M,beta,P,sigma,w);
end
%% recover P
% P_star = P;
end