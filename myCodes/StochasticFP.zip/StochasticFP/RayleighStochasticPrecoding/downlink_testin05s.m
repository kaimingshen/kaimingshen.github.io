Bs = 1;
K = 32;
Bx_N = 64;
Ux_N = 2;
fc = 4.8e9;
% c = 3e8;
c = 1080000000;
T = 10e-5;
sigma = sqrt(10.^([-7:-0.25:-11]));
% sigma = sqrt(10.^(-9));
Pmax = 10^(3);
n=5;

H = zeros(Ux_N, Bx_N, K, Bs, Bs);
Mk = zeros(Ux_N, Bx_N, K, Bs, Bs);

beta = zeros(K,Bs);

Bs_loc = zeros(2,Bs);
Rx_loc_sp = zeros(3,K,Bs);

for b = 2:Bs
    Bs_loc(1,b) = 0.6*cos(pi/3*b);
    Bs_loc(2,b) = 0.6*sin(pi/3*b);
end

for b = 1:Bs
    for k = 1:K
        phi = rand(1)*2*pi;
        r = rand(1)*0.3;
        Rx_loc_sp(1, k, b) = r*cos(phi)+Bs_loc(1, b);
        Rx_loc_sp(2, k, b) = r*sin(phi)+Bs_loc(2, b);
        % Rx_loc_sp(k, 1:2) = rand(1,2)*8-4;
        Rx_loc_sp(3, k, b) = 90;
    end
end

for b = 1:Bs
    for k = 1:K
        for m = 1:Bs
            d = sqrt(sum((Rx_loc_sp(1:2,k,b) - Bs_loc(:,m)).^2));
            Mk(:,:,k,b,m) = sqrt(10.^(-(128.1+37.6*log10(d)+randn(Ux_N,Bx_N)*sqrt(8))/10));
            H(:,:,k,b,m) = Mk(:,:,k,b,m).*(randn(Ux_N,Bx_N)/sqrt(2)+randn(Ux_N,Bx_N)/sqrt(2)*1j);
        end
    end
end

beta = cell(100);
for i = 1:100
    beta{i}=zeros(K,Bs);
for b = 1:Bs
    for k = 1:K
        % beta(n, b, k) = abs(besselj(0, 2*pi*n*Rx_loc_sp(k,3)*fc*T/c));
        % beta(k) = gampdf(2*pi*n*Rx_loc_sp(k,3)*fc*T/c/4e4,1,1);
        % beta{i}(k,b) = abs(besselj(0, 2*pi*n*Rx_loc_sp(3,k)*fc*T/c));
        beta{i}(k,b) = i*0.01;
    end
end
end

P_0 = zeros(Bx_N,Ux_N,K,Bs);
for b = 1:Bs
    for k = 1:K
        tmp = randn(Bx_N,Ux_N)+randn(Bx_N,Ux_N)*1i;
        P_0(:,:,k,b) = tmp/sqrt(real(trace(tmp*tmp')))*sqrt(Pmax);
    end
end
w = ones(K,Bs);


[iter_results_fast,time_fast,ER_fast,P2] = Robust_downlink_fast(H,Mk,P_0,beta{50},sigma(9),w,Pmax);

for i = 1:100
    for si = 1:17
        si
%         [ER0(i,si), ~] = ER_downlink(H,Mk,beta{i},P_0,sigma(si),w);
        % [iter_results_aal,time_aal,ER_aal,P1] = Robust_aal(H,Mk,P_0,beta,sigma(i),w,Pmax);
        % [ER1(i),~]=ER_downlink(H,Mk,beta,P1,sigma(i),w);
        % [iter_results_fast,time_fast,ER_fast,P2] = Robust_downlink_fast(H,Mk,P_0,beta{i},sigma,w,Pmax);
        for b = 1:Bs
            for k = 1:K
                for m = 1:Bs
                    H_bar(:,:,k,b,m) = beta{i}(k,b)*H(:,:,k,b,m);
                end
            end
        end
        R2(i,si) = obj_func_downlink(H,H_bar,Mk,beta{i},P2,sigma(si),w);
        ER_lb(i,si) = ER_lb_2(H,Mk,beta{i},P2,sigma(si),w);
        ER_lb_aal(i,si) = ER_aal(H,Mk,beta{i},P2,sigma(si),w);
        [ER2(i,si),~] = ER_downlink(H,Mk,beta{i},P2,sigma(si),w);
%         [ER_2(i,si),~,ER_ub(i,si)] = ER_upperbound(H,Mk,beta{i},P2,sigma(si),w);
% [iter_results_fast_con,time_fast_con,ER_fast_con,P6] = Fast_downlink(H,Mk,P_0,beta,sigma(i),w,Pmax);
% [ER6(i),~]=ER_downlink(H,Mk,beta,P6,sigma(i),w);
% [iter_results_fp,time_fp,ER_fp,P3] = Robust_downlink(H,Mk,P_0,beta,sigma(i),w,Pmax);
% [ER3(i),~]=ER_downlink(H,Mk,beta,P3,sigma(i),w);
% [iter_results_WMMSE,timeWMMSE,ER_WMMSE,P4]=WMMSE_downlink(H,Mk,P_0,beta,sigma(i),w,Pmax);
% [ER4(i),~]=ER_downlink(H,Mk,beta,P4,sigma(i),w);
% [iter_results_SRWMMSE,time_SRWMMSE,ER_SRWMMSE,P5]=Robust_SRWMMSE(H,Mk,P_0,beta,sigma(i),w,Pmax);
% [ER5(i),~]=ER_downlink(H,Mk,beta,P5,sigma(i),w);
% [iter_results_SWMMSE,time_SWMMSE,ER_SWMMSE,P7]=Robust_SWMMSE(H,Mk,P_0,beta,sigma(i),w,Pmax);
% [ER7(i),~]=ER_downlink(H,Mk,beta,P7,sigma(i),w);
    end
end