clc; clear; close all;
%% ========== 替换成你自己的数据 (4 组) ==========
% 假设您有 4 组实验数据，每组数据包含 7 条曲线
% 曲线名称与原始代码保持一致
x = 0:1:100;
marker_idx = [1 11 21 31 41 51 61 71 81 91 101]; % 只取 10 个点显示 marker
xlim_val = 40; % X 轴只显示到 40 
marker_idx_subset = marker_idx(marker_idx <= xlim_val+1); % 仅在所需范围内显示 marker

% ====== 数据加载 (假设文件存在，此处仅为示例代码，如果文件不存在会报错) ======
% 警告：请确保以下 .mat 文件在 MATLAB 路径中：
% K8_120.mat, K8_120_naka.mat, K16_120.mat, K16_120_naka.mat

try
    load("K16_60.mat");
    y_wmmse_1  = ER_WMMSE(1:41);    
    y_alg1_1   = ER_fp(1:41);   
    y_alg2_1   = ER_fast(1:41);   
    y_rlpd_1   = ER_aal(1:41);   
    y_swmmse_1 = ER_SWMMSE(1:41);     
    y_alg3_1   = iter_results_fp(1:41);   
    y_alg4_1   = iter_results_fast(1:41); 
catch ME
    disp(['警告：文件 K8_120.mat 加载失败。错误信息：' ME.message]);
    % 如果加载失败，用随机数据代替，确保绘图代码可以运行
    y_wmmse_1 = rand(1, 101)*20; y_alg1_1 = rand(1, 101)*20; y_alg2_1 = rand(1, 101)*20;
    y_rlpd_1 = rand(1, 101)*20; y_swmmse_1 = rand(1, 101)*20; y_alg3_1 = rand(1, 101)*20; y_alg4_1 = rand(1, 101)*20;
end

try
    load("K16_60_naka.mat");
    y_wmmse_2  = ER_WMMSE(1:41);    
    y_alg1_2   = ER_fp(1:41);   
    y_alg2_2   = ER_fast(1:41);   
    y_rlpd_2   = ER_aal(1:41);   
    y_swmmse_2 = ER_SWMMSE(1:41);     
    y_alg3_2   = iter_results_fp(1:41);   
    y_alg4_2   = iter_results_fast(1:41); 
catch ME
    disp(['警告：文件 K8_120_naka.mat 加载失败。错误信息：' ME.message]);
    y_wmmse_2 = rand(1, 101)*20; y_alg1_2 = rand(1, 101)*20; y_alg2_2 = rand(1, 101)*20;
    y_rlpd_2 = rand(1, 101)*20; y_swmmse_2 = rand(1, 101)*20; y_alg3_2 = rand(1, 101)*20; y_alg4_2 = rand(1, 101)*20;
end

try
    load("K16_90.mat");
    y_wmmse_3  = ER_WMMSE(1:41);    
    y_alg1_3   = ER_fp(1:41);   
    y_alg2_3   = ER_fast(1:41);   
    y_rlpd_3   = ER_aal(1:41);   
    y_swmmse_3 = ER_SWMMSE(1:41);     
    y_alg3_3   = iter_results_fp(1:41);   
    y_alg4_3   = iter_results_fast(1:41); 
catch ME
    disp(['警告：文件 K16_120.mat 加载失败。错误信息：' ME.message]);
    y_wmmse_3 = rand(1, 101)*100; y_alg1_3 = rand(1, 101)*100; y_alg2_3 = rand(1, 101)*100;
    y_rlpd_3 = rand(1, 101)*100; y_swmmse_3 = rand(1, 101)*100; y_alg3_3 = rand(1, 101)*100; y_alg4_3 = rand(1, 101)*100;
end

try
    load("K16_90_naka.mat");
    y_wmmse_4  = ER_WMMSE(1:41);    
    y_alg1_4   = ER_fp(1:41);   
    y_alg2_4   = ER_fast(1:41);   
    y_rlpd_4   = ER_aal(1:41);   
    y_swmmse_4 = ER_SWMMSE(1:41);     
    y_alg3_4   = iter_results_fp(1:41);   
    y_alg4_4   = iter_results_fast(1:41); 
catch ME
    disp(['警告：文件 K16_120_naka.mat 加载失败。错误信息：' ME.message]);
    y_wmmse_4 = rand(1, 101)*100; y_alg1_4 = rand(1, 101)*100; y_alg2_4 = rand(1, 101)*100;
    y_rlpd_4 = rand(1, 101)*100; y_swmmse_4 = rand(1, 101)*100; y_alg3_4 = rand(1, 101)*100; y_alg4_4 = rand(1, 101)*100;
end
x = 0:1:40;

% 将四组数据打包成 Cell 数组，便于循环
all_y = { 
    {y_wmmse_1, y_alg1_1, y_alg2_1, y_rlpd_1, y_swmmse_1, y_alg3_1, y_alg4_1};
    {y_wmmse_2, y_alg1_2, y_alg2_2, y_rlpd_2, y_swmmse_2, y_alg3_2, y_alg4_2};
    {y_wmmse_3, y_alg1_3, y_alg2_3, y_rlpd_3, y_swmmse_3, y_alg3_3, y_alg4_3};
    {y_wmmse_4, y_alg1_4, y_alg2_4, y_rlpd_4, y_swmmse_4, y_alg3_4, y_alg4_4};
};

%% --- Y 轴范围和刻度设置 ---
% {YLim_range, YTick_values}
y_axis_settings = {
    {[0 300], [0:50:300]};    % Subplot 1 (K8, Rayleigh)
    {[0 300], [0:50:300]};    % Subplot 2 (K8, Nakagami)
    {[0 160], [0:40:160]}; % Subplot 3 (K16, Rayleigh) - **YTick 修正**
    {[0 160], [0:40:160]}; % Subplot 4 (K16, Nakagami) - **YTick 修正**
};
x_tick_val = 0:10:xlim_val; % 即 [0, 10, 20, 30, 40]

%% ========= 定义绘图参数 =========
plot_styles = {
    {'--+','Color',[0.8500 0.3250 0.0980],'MarkerFaceColor','none'}, % WMMSE
    {'-s','Color',[0.4940 0.1840 0.5560],'MarkerFaceColor','none'},  % Algorithm 1
    {'-s','Color',[0 0.4470 0.7410],'MarkerFaceColor','none'},       % Algorithm 2
    {':d','Color',[0.4660 0.6740 0.1880],'MarkerFaceColor','none'},  % RLPD
    {'--o','Color',[0.9290 0.6940 0.1250],'MarkerFaceColor','none'}, % SWMMSE
    {'-^','Color',[0.3010 0.7450 0.9330],'MarkerFaceColor','none'},  % Algorithm 3 (Lower bound 1)
    {'-.v','Color',[0.6350 0.0780 0.1840],'MarkerFaceColor','none'}  % Algorithm 4 (Lower bound 2)
};
line_width = 1.5;
marker_size = 6;
font_size = 12;

% 新增/修改的标题信息
titles = {
    '60km/h, Rayleigh fading case';
    '60km/h, Nakagami-$m$ fading case';
    '90km/h, Rayleigh fading case';
    '90km/h, Nakagami-$m$ fading case'
};
title_font_size = font_size-0; 

%% ========= 画图 (均匀分布) =========
% 创建一个 Figure，总宽度调整为 1120
figure('Position',[100 100 1120 420]); 
% --- 均匀分布计算参数 (重点修改) ---
w = 0.19;  % 子图宽度 (不变)
h = 0.75;  % 子图高度：增加高度以利用上方空白空间 (原 0.7)
b = 0.2;  % 底部位置：减小底部位置，但同时为 X 轴标签和新标题保留空间 (原 0.2)
% 均匀分布计算
total_width = 4 * w; 
remaining_space = 1.0 - total_width; 
M = remaining_space / 5; 
Delta = M; 
M = M+0.005;

subplot_positions = {
    [M, b, w, h];
    [M + 1*(w + Delta), b, w, h];
    [M + 2*(w + Delta), b, w, h];
    [M + 3*(w + Delta), b, w, h];
};

% **修改：调整标题垂直位置的参数**
title_y_offset_norm = -0.25; 

for k = 1:4 % 循环 4 次，绘制 4 个子图
    % 使用 subplot('Position', ...) 精确控制位置和大小
    h_ax = subplot('Position', subplot_positions{k}); 
    
    hold on; grid on;
    
    current_data = all_y{k};
    
    % 绘制 7 条曲线
    for i = 1:7
        style = plot_styles{i};
        plot(x, current_data{i}, style{:}, ...
             'LineWidth', line_width, ...
             'MarkerSize', marker_size, ...
             'MarkerIndices', marker_idx_subset); 
    end
    
    %% ========== 坐标轴和刻度设置 ==========
    set(h_ax,'FontSize',font_size,'FontName','Times New Roman');
    set(h_ax,'Box','on');
    
    % --- X 轴设置：范围和刻度 ---
    xlim([0 xlim_val]); 
    set(h_ax, 'XTick', x_tick_val); 
    
    % Y 轴设置
    current_ylim = y_axis_settings{k}{1};
    current_ytick = y_axis_settings{k}{2};
    ylim(current_ylim);
    set(h_ax, 'YTick', current_ytick);
    
    % 仅在第一个子图添加 Y 轴标签 (保持原样，只在第一个图显示 Y 轴文字)
    if k == 1
        ylabel('Average Sum Rate (bits/s/Hz)', ...
               'FontSize',font_size+2,'FontWeight','normal','Interpreter','latex');
    end
    
    % !!! 关键修正 !!!
    % 移除原代码中隐藏 k=2 和 k=4 的 Y 轴刻度标签的逻辑，
    % 以确保所有子图都显示 Y 轴刻度标签。
    % 原始代码：
    % if k == 2 || k == 4
    %      set(h_ax, 'YTickLabel', []);
    % end
    
    % 在每个子图下方添加 X 轴标签
    xlabel('Iteration Number', ...
           'FontSize',font_size+2,'FontWeight','normal','Interpreter','latex');
    
    
    % **标题放置：子图下方并居中**
    full_title = sprintf('(%s) %s', char('a' + k - 1), titles{k});
    
    % 使用 text 函数添加标题
    h_title = text(0.5, title_y_offset_norm, full_title, ... 
        'Units', 'normalized', ...           % 使用 Axes 的归一化坐标 (0-1)
        'HorizontalAlignment', 'center', ...  % 水平居中
        'VerticalAlignment', 'bottom', ...    % 垂直对齐到底部
        'FontSize', title_font_size, ...
        'FontWeight', 'bold', ...
        'Interpreter', 'latex', ...
        'Parent', h_ax); 
    
    
    %% ========== 网格 ==========
    ax = h_ax;
    ax.GridAlpha = 0.25;
    ax.XMinorGrid = 'off';
    ax.YMinorGrid = 'off';
    ax.XMinorTick = 'off';
    ax.YMinorTick = 'off';
    
    hold off;
end

%% ========== 图例 (统一添加在最后一个子图区域右侧) ==========
% 由于使用了手动 Position，这里使用最后一个 Axes Handle 添加图例
h_legend = legend(h_ax, ... 
       {'WMMSE','Algorithm 1','Algorithm 2','RLPD','SWMMSE',...
        'Lower bound with Alg. 1','Lower bound with Alg. 2'}, ...
       'FontSize',font_size, ...
       'FontName','Times New Roman', ...
       'Location','southwest', ... % 使用 southwest 以便调整到最右侧
       'EdgeColor',[0.3 0.3 0.3], ...
       'Interpreter','latex');
       
% 假设希望图例左侧位于最后一个子图右侧 0.02 的位置
legend_left = subplot_positions{4}(1) + subplot_positions{4}(3) + 0.02;
       
% 调整图例位置到 Figure 的最右侧，并靠近底部
legend_pos = get(h_legend, 'Position');
legend_pos(1) = legend_left; % 设置图例左边界
set(h_legend, 'Position', legend_pos);