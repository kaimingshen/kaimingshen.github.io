function [W,iter_results,time] = FFP_beamforming(H,d,W,mu,Pmax,sigma,MaxIter)
%UNTITLED5 此处显示有关此函数的摘要
%   此处显示详细说明
[N,M,K] = size(H); Y = zeros(N,d,K);
iter_results = zeros(MaxIter+1,1); time = zeros(MaxIter,1);
eps = 1e-6;
pre_W = W;
for iter = 1:MaxIter
    if iter>10 && abs(iter_results(iter-1)-iter_results(iter-2))/iter_results(iter-2)<eps
        break
    end
    tic
    beta = (iter-1)/(iter+2);
    ex_W = W+beta*(W-pre_W);
    %% update Ga using ex_W
    [HW,S_HWWH_I,Ga,iter_results(iter)] = MIMO_obj(H,ex_W,mu,sigma);
    %% update Y
    for k = 1:K
        Y(:,:,k) = (S_HWWH_I(:,:,k))\HW(:,:,k,k);
    end

    T = ex_W;
    pre_W = W;

    %% update W
    L = zeros(M,M);
    for j = 1:K
        HY = H(:,:,j)'*Y(:,:,j);
        L = L+mu(j)*HY*(eye(d)+Ga(:,:,j))*HY';
    end
    lambda = norm(L,'fro');
    % lambda = norm(L,'fro');
        % lambda = eigs(L,1);

    for k = 1:K
        W(:,:,k) = T(:,:,k)+1/lambda*(H(:,:,k)'*mu(k)*Y(:,:,k)*(eye(d)+Ga(:,:,k))-L*T(:,:,k));
    end
    [flag,sumP] = check_power(W,Pmax);
    if flag == 0
        W = W*sqrt(Pmax/sumP);
    end
    t_run = toc;
    if iter>1
        time(iter) = time(iter-1)+t_run;
    else
        time(iter) = t_run;
    end
end
[~,~,~,iter_results(iter)] = MIMO_obj(H,W,mu,sigma);
end