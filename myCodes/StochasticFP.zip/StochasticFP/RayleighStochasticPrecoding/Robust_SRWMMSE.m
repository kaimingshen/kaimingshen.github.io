function [iter_results,time,ER_results,P_star] = Robust_SRWMMSE(H_hat,M,P,beta,sigma,w,Pmax)
%UNTITLED5 此处显示有关此函数的摘要
%   P is the beamformer
[Ux_N, Bx_N, K, Bs,~] = size(H_hat);
H_bar = zeros(Ux_N, Bx_N, K, Bs, Bs);
for b = 1:Bs
    for k = 1:K
        for m = 1:Bs
            H_bar(:,:,k,b,m) = beta(k,b)*H_hat(:,:,k,b,m);
        end
    end
end


% initialize U
U_k = zeros(Ux_N,Ux_N,K,Bs);
W = zeros(Ux_N,Ux_N,K,Bs);

MaxIter = 21;
iter_results = zeros(MaxIter,1);
ER_results = zeros(MaxIter,1);
% [iter_results(1), ~, ~] = obj_func_downlink(H_hat,H_bar,M,ones(K,1),P,sigma,w);
[ER_results(1), ~] = ER_downlink(H_hat,M,beta,P,sigma,w);
time = zeros(MaxIter,1);
eps = 1e-6;
for iter = 2:MaxIter
%     if iter>10 && abs(iter_results(iter-1)-iter_results(iter-2))/iter_results(iter-2)<eps
%         break
%     end
    tic
    %% channel generation
    H_r = zeros(Ux_N, Bx_N, K, Bs, Bs);
    for k = 1:K
        for b = 1:Bs
            for m = 1:Bs
                H_r(:,:,k,b,m) = H_bar(:,:,k,b,m) + sqrt(1-beta(k)^2)*(M(:,:,k,b,m).*(randn(Ux_N,Bx_N)/sqrt(2)+randn(Ux_N,Bx_N)*1j/sqrt(2)));
            end
        end
    end

    for b = 1:Bs
        
        %% update U
        dom = zeros(Ux_N,Ux_N, K);
        for k = 1:K
            for l = 1:K
                tmp = H_r(:,:,k,b,b)*P(:,:,l,b);
                dom(:,:,k) = dom(:,:,k)+sigma^2/Pmax*trace(P(:,:,l,b)*P(:,:,l,b)')*eye(Ux_N)+tmp*tmp';
            end
            U_k(:,:,k) = pinv(dom(:,:,k))*H_r(:,:,k,b,b)*P(:,:,k,b);
        end
        %% update W
        for k = 1:K
            W(:,:,k) = pinv(eye(Ux_N)-U_k(:,:,k)'*H_r(:,:,k,b,b)*P(:,:,k,b));
        end
    
        %% update X
        UWU = zeros(Ux_N,Ux_N, K);
        bet = 0;
        for i = 1:K
            UWU(:,:,i) = U_k(:,:,i)*W(:,:,i)*U_k(:,:,i)';
            bet = bet + sigma^2/Pmax*w(i,b)*trace(UWU(:,:,i));
        end
        rho = sqrt(1/(1-beta(1)^2)-1)*8/(iter-1);
    
        L = (bet+1/(2*rho))*eye(Bx_N);
        for i = 1:K
            L = L+w(i,b)*H_r(:,:,i,b,b)'*UWU(:,:,i)*H_r(:,:,i,b,b);
        end
        invL = pinv(L);
        sumP = 0;
        for k = 1:K
            P(:,:,k,b) = invL*(w(k,b)*H_r(:,:,k,b,b)'*U_k(:,:,k)*W(:,:,k)+1/(2*rho)*P(:,:,k,b));
            sumP = sumP + real(trace(P(:,:,k,b)'*P(:,:,k,b)));
        end
        P(:,:,:,b) = P(:,:,:,b)*sqrt(Pmax/sumP);
    end

    t_run = toc;
    time(iter) = time(iter-1)+t_run;
%     if time(iter)>0.5 && iter>2
%         break;
%     end
    P_star = P;

%     [iter_results(iter), R_lb, ~] = obj_func_downlink(H_hat,H_bar,M,ones(K,1),P,sigma,w);
    [ER_results(iter), ~] = ER_downlink(H_hat,M,beta,P,sigma,w);
end
%% recover P
% P_star = P;
end