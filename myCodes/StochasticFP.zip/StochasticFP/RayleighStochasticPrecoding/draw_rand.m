clc; clear; close all;
%% ========== 替换成你自己的数据 (2 组) ==========
% 假设您有 2 组实验数据（原代码的前两组 K8），每组数据包含 7 条曲线
x = 0:1:50;
marker_idx = [1 11 21 31 41 51 61 71 81 91 101]; % 只取 10 个点显示 marker
xlim_val = 40; % X 轴只显示到 40 
marker_idx_subset = marker_idx(marker_idx <= xlim_val+1); % 仅在所需范围内显示 marker

% ====== 数据加载 (假设文件存在，此处仅为示例代码，如果文件不存在会报错) ======
% 警告：请确保以下 .mat 文件在 MATLAB 路径中：
% K8_90.mat, K8_90_naka.mat

    load("K8_90_rand.mat");
    y_wmmse_1  = ER_WMMSE(1:51);    
    y_alg1_1   = ER_fp(1:51);   
    y_alg2_1   = ER_fast(1:51);   
    y_rlpd_1   = ER_aal(1:51);   
    y_swmmse_1 = ER_SWMMSE(1:51);     
    y_alg3_1   = iter_results_fp(1:51);   
    y_alg4_1   = iter_results_fast(1:51); 

    load("K8_90_naka_rand.mat");
    y_wmmse_2  = ER_WMMSE(1:51);    
    y_alg1_2   = ER_fp(1:51);   
    y_alg2_2   = ER_fast(1:51);   
    y_rlpd_2   = ER_aal(1:51);   
    y_swmmse_2 = ER_SWMMSE(1:51);     
    y_alg3_2   = iter_results_fp(1:51);   
    y_alg4_2   = iter_results_fast(1:51); 

x = 0:1:50;

% 将两组数据打包成 Cell 数组，便于循环 (只取前两组)
all_y = { 
    {y_wmmse_1, y_alg1_1, y_alg2_1, y_rlpd_1, y_swmmse_1, y_alg3_1, y_alg4_1};
    {y_wmmse_2, y_alg1_2, y_alg2_2, y_rlpd_2, y_swmmse_2, y_alg3_2, y_alg4_2};
};

% 只有 2 组数据，只取前两组设置
y_axis_settings = {
    {[0 25], [0:5:25]};    % Subplot 1 (K8, Rayleigh)
    {[0 25], [0:5:25]};    % Subplot 2 (K8, Nakagami)
};
x_tick_val = 0:10:xlim_val; % 即 [0, 10, 20, 30, 40]

%% ========= 定义绘图参数 (与原代码保持一致) =========
plot_styles = {
    {'--+','Color',[0.8500 0.3250 0.0980],'MarkerFaceColor','none'}, % WMMSE
    {'-s','Color',[0.4940 0.1840 0.5560],'MarkerFaceColor','none'},  % Algorithm 1
    {'-s','Color',[0 0.4470 0.7410],'MarkerFaceColor','none'},       % Algorithm 2
    {':d','Color',[0.4660 0.6740 0.1880],'MarkerFaceColor','none'},  % RLPD
    {'--o','Color',[0.9290 0.6940 0.1250],'MarkerFaceColor','none'}, % SWMMSE
    {'-^','Color',[0.3010 0.7450 0.9330],'MarkerFaceColor','none'},  % Algorithm 3 (Lower bound 1)
    {'-.v','Color',[0.6350 0.0780 0.1840],'MarkerFaceColor','none'}  % Algorithm 4 (Lower bound 2)
};
line_width = 1.5;
marker_size = 6;
font_size = 12;

% 标题信息 (只取前两个)
titles = {
    'Single-cell Rayleigh fading case';
    'Single-cell Nakagami-$m$ fading case';
};
title_font_size = font_size; 

%% ========= 画图 (均匀分布) =========
% 关键修改 1：总宽度缩到原来的一半 (1120 / 2 = 560)
figure('Position',[100 100 560 420]); 

% --- 均匀分布计算参数 (重点修改) ---
num_plots = 2; % 只有 2 个子图
w = 0.35;  % 子图宽度：增大子图宽度以充分利用空间 (原 0.19)
h = 0.75;  % 子图高度 (不变)
b = 0.2;  % 底部位置 (不变)

% 关键修改 2：均匀分布计算 (适应 2 个子图)
total_width = num_plots * w; 
remaining_space = 1.0 - total_width; 
M = remaining_space / 3; % 2个子图，3个间隙 (左，中，右)
Delta = M; 
M = M+0.005; % 微调左边距

subplot_positions = {
    [M, b, w, h];
    [M + 1*(w + Delta), b, w, h];
};

title_y_offset_norm = -0.25; 

for k = 1:num_plots % 循环 2 次，绘制 2 个子图
    % 使用 subplot('Position', ...) 精确控制位置和大小
    h_ax = subplot('Position', subplot_positions{k}); 
    
    hold on; grid on;
    
    current_data = all_y{k};
    
    % 绘制 7 条曲线
    for i = 1:7
        style = plot_styles{i};
        plot(x, current_data{i}, style{:}, ...
             'LineWidth', line_width, ...
             'MarkerSize', marker_size, ...
             'MarkerIndices', marker_idx_subset); 
    end
    
    %% ========== 坐标轴和刻度设置 ==========
    set(h_ax,'FontSize',font_size,'FontName','Times New Roman');
    set(h_ax,'Box','on');
    
    % --- X 轴设置：范围和刻度 ---
    xlim([0 xlim_val]); 
    set(h_ax, 'XTick', x_tick_val); 
    
    % Y 轴设置
    current_ylim = y_axis_settings{k}{1};
    current_ytick = y_axis_settings{k}{2};
    ylim(current_ylim);
    set(h_ax, 'YTick', current_ytick);
    
    % 仅在第一个子图添加 Y 轴标签
    if k == 1
        ylabel('Average Sum Rate (bits/s/Hz)', ...
               'FontSize',font_size+2,'FontWeight','normal','Interpreter','latex');
    end
    
    % 在每个子图下方添加 X 轴标签
    xlabel('Iteration Number', ...
           'FontSize',font_size+2,'FontWeight','normal','Interpreter','latex');
    
    
    % **标题放置：子图下方并居中**
    full_title = sprintf('(%s) %s', char('a' + k - 1), titles{k});
    
    % 使用 text 函数添加标题
    h_title = text(0.5, title_y_offset_norm, full_title, ... 
        'Units', 'normalized', ...           % 使用 Axes 的归一化坐标 (0-1)
        'HorizontalAlignment', 'center', ...  % 水平居中
        'VerticalAlignment', 'bottom', ...    % 垂直对齐到底部
        'FontSize', title_font_size, ...
        'FontWeight', 'bold', ...
        'Interpreter', 'latex', ...
        'Parent', h_ax); 
    
    
    %% ========== 网格 ==========
    ax = h_ax;
    ax.GridAlpha = 0.25;
    ax.XMinorGrid = 'off';
    ax.YMinorGrid = 'off';
    ax.XMinorTick = 'off';
    ax.YMinorTick = 'off';
    
    hold off;
end

%% ========== 图例 (统一添加在第二个子图区域右侧) ==========
% 使用第二个 (最后一个) Axes Handle 添加图例
h_legend = legend(h_ax, ... 
       {'WMMSE','Algorithm 1','Algorithm 2','RLPD','SWMMSE',...
        'Lower bound with Alg. 1','Lower bound with Alg. 2'}, ...
       'FontSize',font_size, ...
       'FontName','Times New Roman', ...
       'Location','southwest', ... % 使用 southwest 以便调整到最右侧
       'EdgeColor',[0.3 0.3 0.3], ...
       'Interpreter','latex');
       
% 假设希望图例左侧位于第二个子图右侧 0.02 的位置
legend_left = subplot_positions{2}(1) + subplot_positions{2}(3) + 0.02;
       
% 调整图例位置到 Figure 的最右侧，并靠近底部
legend_pos = get(h_legend, 'Position');
legend_pos(1) = legend_left; % 设置图例左边界
set(h_legend, 'Position', legend_pos);