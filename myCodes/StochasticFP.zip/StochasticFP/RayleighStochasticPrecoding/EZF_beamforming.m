function [W] = EZF_beamforming(H,d,P)
%UNTITLED4 此处显示有关此函数的摘要
%   此处显示详细说明
[~,M,K] = size(H);
Vbar = zeros(M,d*K);
for k = 1:K
    [~,~,V]=svd(H(:,:,k));
    Vbar(:,(k-1)*d+1:k*d) = V(:,1:d);
end
Wbar = Vbar/(Vbar'*Vbar);
% 列归一，每一列的norm2变为1，数据流功率等分配
for i = 1:d*K
    Wbar(:,i) = Wbar(:,i)/norm(Wbar(:,i));
end
Wbar = Wbar/(sqrt(trace(Wbar*Wbar')))*sqrt(P);
W = reshape(Wbar,[M,d,K]); 
% P_n = 0;
% for k = 1:K
%     P_n = trace(W(:,:,k)*W(:,:,k)')+P_n;
% end

end