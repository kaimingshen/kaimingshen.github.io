%% 1. 数据准备 (Data Preparation)
% 定义 X 轴 (rho_jk) 和 Y 轴 (sigma^2) 的范围
% 对应图中的 x: 0 到 1, y: -110 到 -70
rho = 0.01:0.01:100;             
sigma_dbm = -7:-0.25:-11;  
% 生成网格矩阵
[R, S] = meshgrid(rho, sigma_dbm);
%% 2. 计算 Z 轴数值 (Calculate Z Data)
% -----------------------------------------------------------
% 【重要】：这里使用的是模拟公式，请替换为你自己的真实数据矩阵！
% -----------------------------------------------------------
% 第一组数据 (红色 - 对应图中 "Lower Bound in [12]")
% 形状模拟：中间隆起，两边低
Z1_Red = gap1; 
% 第二组数据 (蓝色 - 对应图中 "Proposed Lower Bound")
% 形状模拟：比较平缓，数值较低
Z2_Blue = gap2;
% 第三组数据 (绿色 - 新加的数据)
% 形状模拟：假设它是介于两者之间，或者是另一种新的界
Z3_Green = gap3; 
%% 3. 绘图 (Plotting)
figure('Color', 'w'); % 设置背景为白色
% 画第一组 (红色网格)
mesh(R, S, Z1_Red, 'EdgeColor', 'r', 'FaceColor', 'none', 'DisplayName', 'Lower Bound in [12]');
hold on;
% 画第二组 (蓝色网格)
mesh(R, S, Z2_Blue, 'EdgeColor', 'b', 'FaceColor', 'none', 'DisplayName', 'Proposed Lower Bound');
% 画第三组 (绿色网格 - 新数据)
mesh(R, S, Z3_Green, 'EdgeColor', '#009900', 'FaceColor', 'none', 'DisplayName', 'New 3rd Dataset');
% 注意：'#009900' 是深绿色，也可以直接用 'g'
%% 4. 美化与标注 (Formatting)
% 坐标轴标签 (使用 LaTeX 格式)
xlabel('$\rho_{jk}$', 'Interpreter', 'latex', 'FontSize', 14);
ylabel('$\sigma^2$ (dBm)', 'Interpreter', 'latex', 'FontSize', 14);
zlabel('Error of Lower Bounds', 'FontSize', 12);
% 设置坐标轴范围 (根据图片调整)
xlim([0 1]);
ylim([-110 -70]);
zlim([0 16]); % 根据Z数据的最大值调整
% 调整视角 (View Angle) - 模仿原图的角度
view(135, 30); 
% 添加图例 (Legend) - 这是区分三组数据最清晰的方法
legend('show', 'Location', 'northeast');
% 开启网格
grid on;
box on;
% (可选) 如果你想模仿图中那样用箭头和文字标注
% 注意：3D图中的文字位置(x,y,z)需要根据你的数据手动微调
% ---------------------------------------------------------
% 标注红色曲线
text(0.2, -100, 12, '\leftarrow Lower Bound in [12]', ...
    'Color', 'r', 'FontSize', 10, 'FontWeight', 'bold');
% 标注蓝色曲线
text(0.5, -80, 2, 'Proposed Lower Bound \rightarrow', ...
    'Color', 'b', 'FontSize', 10, 'FontWeight', 'bold', 'HorizontalAlignment', 'right');
hold off;