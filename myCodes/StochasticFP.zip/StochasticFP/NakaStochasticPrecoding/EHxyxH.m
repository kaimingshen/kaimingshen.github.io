function [E] = EHxyxH(H_hat,M,x,y,beta)
A = x*y*x';
Aii = diag(A);
B = M.^2*Aii;
H_hatx = beta*H_hat*x;
E = (H_hatx*y*H_hatx') + (1-beta^2)*diag(B);
end