function [obj, R_lb, int] = ER_lb_2(H_hat,M,beta,P,sigma,w)

[Ux_N, Bx_N, K, Bs,~] = size(H_hat);
H_bar = zeros(Ux_N, Bx_N, K, Bs, Bs);
for b = 1:Bs
    for k = 1:K
        for m = 1:Bs
            H_bar(:,:,k,b,m) = beta(k,b)*H_hat(:,:,k,b,m);
        end
    end
end


int = zeros(Ux_N, Ux_N, K, Bs);
noise = zeros(K, Bs);
for b = 1:Bs
    for k = 1:K
        for m = 1:Bs
            for l = 1:K
                if l~=k || m~=b
                    Hp = H_bar(:,:,k,b,m)*P(:,:,l,m);
                    int(:,:,k,b) = int(:,:,k,b) + Hp*Hp';
                    Hp = M(:,:,k,b,m)*P(:,:,l,m);
                    noise(k, b) = noise(k, b)+(1-beta(k,b)^2)*real(trace(Hp*Hp'));
                end
            end
        end
        Hp = M(:,:,k,b,b)*P(:,:,k,b);
        noise(k, b) = noise(k, b)+(1-beta(k,b)^2)*real(trace(Hp*Hp'));
    end
end

R_lb = zeros(K,Bs);
for b = 1:Bs
    for k = 1:K
        H_barp = H_bar(:,:,k,b,b)*P(:,:,k,b);
        R_lb(k,b) = log2(real(det(eye(Ux_N)+H_barp'*pinv((sigma^2+noise(k,b))*eye(Ux_N)+int(:,:,k,b))*H_barp)));
    end
end

obj = sum(sum(R_lb.*w));
end