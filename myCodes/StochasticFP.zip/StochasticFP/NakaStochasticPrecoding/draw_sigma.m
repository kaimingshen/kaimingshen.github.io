 % clc; clear; close all;

%% ========== 替换成你自己的数据 ==========

% 横轴：迭代次数（0:1:100）
x = -7:-0.25:-11;

% 原始5条曲线（示例数据，可替换）
y_wmmse  = ER4;    
y_alg1   = ER2;   
y_alg2   = ER1;   
y_rlpd   = ER7;   



%% === 只取 10 个点显示 marker ===
marker_idx = 1:17;

%% ========= 画图 =========
figure('Position',[300 200 560 420]);
hold on; grid on;

% WMMSE
plot(x, y_wmmse,'--+','Color',[0.8500 0.3250 0.0980], ...
     'LineWidth',1.5,'MarkerSize',6,'MarkerIndices',marker_idx);

% Algorithm 1
plot(x, y_alg1,'-s','Color',[0 0.4470 0.7410], ...
     'LineWidth',1.5,'MarkerSize',6,'MarkerFaceColor','none', ...
     'MarkerIndices',marker_idx);

% Algorithm 2
plot(x, y_alg2,':d','Color',[0.4660 0.6740 0.1880], ...
     'LineWidth',1.5,'MarkerSize',6,'MarkerFaceColor','none', ...
     'MarkerIndices',marker_idx);

% RLPD
plot(x, y_rlpd,'--o','Color',[0.9290 0.6940 0.1250], ...
     'LineWidth',1.5,'MarkerSize',6,'MarkerFaceColor','none', ...
     'MarkerIndices',marker_idx);




%% ========== 坐标轴 ==========
set(gca,'FontSize',12,'FontName','Times New Roman');
set(gca,'Box','on');

xlabel('$$\sigma^2$$ (dBm)', ...
       'FontSize',14,'FontWeight','normal','Interpreter','latex');

ylabel('Average Sum Rate (bits/s/Hz)', ...
       'FontSize',14,'FontWeight','normal','Interpreter','latex');

xlim([-11 -7]);
ylim([0 35]);


%% ========== 图例 ==========
legend({'WMMSE','Algorithm 1 (or 2)','RLPD','SWMMSE',...
        'Lower bound with Alg. 1','Lower bound with Alg. 2'}, ...
       'FontSize',12,'FontName','Times New Roman', ...
       'Location','southeast','EdgeColor',[0.3 0.3 0.3], ...
       'Interpreter','latex');


%% ========== 网格 ==========
ax = gca;
ax.GridAlpha = 0.25;
ax.XMinorGrid = 'off';
ax.YMinorGrid = 'off';
ax.XMinorTick = 'off';
ax.YMinorTick = 'off';
ax.XDir = 'reverse';
ax.XTickLabel = [-70:-5:-110];

hold off;
