function [P] = updateP_aal(D_b,A,F_b,P_0,w,Pmax)
[Bx_N, Ux_N, K] = size(P_0);

eps=1e-6;
P = zeros(Bx_N, Ux_N, K);

eta = 0; 
sumP = 0;
invD = pinv(D_b+eta*eye(Bx_N));
for k = 1:K
    P(:,:,k) = invD*(w(k)*A(:,:,k)+F_b(:,:,k))*P_0(:,:,k);
    sumP = sumP + real(trace(P(:,:,k)'*P(:,:,k)));
end
if sumP <= Pmax
    return
end

eta = 2;
sumP = 0;
invD = pinv(D_b+eta*eye(Bx_N));
for k = 1:K
    P(:,:,k) = invD*(w(k)*A(:,:,k)+F_b(:,:,k))*P_0(:,:,k);
    sumP = sumP + real(trace(P(:,:,k)'*P(:,:,k)));
end
while sumP > Pmax
    eta = eta^2;
    sumP = 0;
    invD = pinv(D_b+eta*eye(Bx_N));
    for k = 1:K
        P(:,:,k) = invD*(w(k)*A(:,:,k)+F_b(:,:,k))*P_0(:,:,k);
        sumP = sumP + real(trace(P(:,:,k)'*P(:,:,k)));
    end
end

ub = eta;
%% find lb
if eta == 2
    lb = 0;
else
    lb = sqrt(eta);
end
sumP = 0;
invD = pinv(D_b+eta*eye(Bx_N));
for k = 1:K
    P(:,:,k) = invD*(w(k)*A(:,:,k)+F_b(:,:,k))*P_0(:,:,k);
    sumP = sumP + real(trace(P(:,:,k)'*P(:,:,k)));
end
iter = 0;
while (Pmax-sumP)/Pmax>eps
    if iter>1000 && Pmax>sumP
        break
    end
    iter = iter+1;
    mid = (lb+ub)/2;
    eta = mid;
    sumP = 0;
    invD = pinv(D_b+eta*eye(Bx_N));
    for k = 1:K
        P(:,:,k) = invD*(w(k)*A(:,:,k)+F_b(:,:,k))*P_0(:,:,k);
        sumP = sumP + real(trace(P(:,:,k)'*P(:,:,k)));
    end
    if sumP > Pmax
        lb = mid;
    else
        ub = mid;
    end
    eta = ub;
    sumP = 0;
    invD = pinv(D_b+eta*eye(Bx_N));
    for k = 1:K
        P(:,:,k) = invD*(w(k)*A(:,:,k)+F_b(:,:,k))*P_0(:,:,k);
        sumP = sumP + real(trace(P(:,:,k)'*P(:,:,k)));
    end
end
end