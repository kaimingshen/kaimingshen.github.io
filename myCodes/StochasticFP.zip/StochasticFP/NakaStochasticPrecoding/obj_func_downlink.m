function [obj, R_lb, int] = obj_func_downlink(H_hat,H_bar,M,beta,P,sigma,w)

[Ux_N, Bx_N, K, Bs, ~] = size(H_hat);

int = zeros(Ux_N, Ux_N, K, Bs);
for b = 1:Bs
    for k = 1:K
        for m = 1:Bs
            for l = 1:K
                int(:,:,k,b) = int(:,:,k,b) + EHxxH(H_hat(:,:,k,b,m),M(:,:,k,b,m),P(:,:,l,m),beta(k,b));
            end
        end
    end
end

R_lb = zeros(K,Bs);
for b = 1:Bs
    for k = 1:K
        H_barp = H_bar(:,:,k,b,b)*P(:,:,k,b);
        R_lb(k,b) = log2(real(det(eye(Ux_N)+H_barp'*pinv(sigma^2*eye(Ux_N)+int(:,:,k,b)-H_barp*H_barp')*H_barp)));
    end
end

obj = sum(sum(R_lb.*w));
end