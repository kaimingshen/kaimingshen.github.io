Bs = 7;
K = 16;
Bx_N = 32;
Ux_N = 2;
fc = 4.8e9;
% c = 3e8;
c = 1080000000;
T = 10e-5;
% sigma = sqrt(10.^([-7:-0.25:-11]));
sigma = sqrt(10.^(-9));
Pmax = 10^(3);
n=5;

D = 10;
Samples = 1000;

H = zeros(Ux_N, Bx_N, K, Bs, Bs);
Mk = zeros(Ux_N, Bx_N, K, Bs, Bs);
H_samples = zeros(Ux_N, Bx_N, K, Bs, Bs, Samples);
W = zeros(Ux_N, Bx_N, K, Bs, Bs);

beta = zeros(K,Bs);

Bs_loc = zeros(2,Bs);
Rx_loc_sp = zeros(3,K,Bs);


for b = 2:Bs
    Bs_loc(1,b) = 0.6*cos(pi/3*b);
    Bs_loc(2,b) = 0.6*sin(pi/3*b);
end

for b = 1:Bs
    for k = 1:K
        phi = rand(1)*2*pi;
        r = rand(1)*0.3;
        Rx_loc_sp(1, k, b) = r*cos(phi)+Bs_loc(1, b);
        Rx_loc_sp(2, k, b) = r*sin(phi)+Bs_loc(2, b);
        % Rx_loc_sp(k, 1:2) = rand(1,2)*8-4;
        Rx_loc_sp(3, k, b) = 90;
    end
end

for b = 1:Bs
    for k = 1:K
        for m = 1:Bs
            d = sqrt(sum((Rx_loc_sp(1:2,k,b) - Bs_loc(:,m)).^2));
            Mk(:,:,k,b,m) = sqrt(10.^(-(128.1+37.6*log10(d)+randn(1)*ones(Ux_N,Bx_N)*sqrt(8))/10));
            H(:,:,k,b,m) = arrayfun(@(omega) random(makedist('Nakagami', 'mu',0.5, 'omega', omega), 1)*exp(2*pi*rand(1)*1j), Mk(:,:,k,b,m).^2);
        end
    end
end

for b = 1:Bs
    for k = 1:K
        % beta(n, b, k) = abs(besselj(0, 2*pi*n*Rx_loc_sp(k,3)*fc*T/c));
        % beta(k) = gampdf(2*pi*n*Rx_loc_sp(k,3)*fc*T/c/4e4,1,1);
        beta(k,b) = abs(besselj(0, 2*pi*n*Rx_loc_sp(3,k)*fc*T/c));
    end
end

W(:,:,:,:,:) = Mk;
for s = 1:Samples
    s
    for b = 1:Bs
        for k = 1:K
            for m = 1:Bs
                H_samples(:,:,k,b,m,s) = beta(k,b)*H(:,:,k,b,m)+sqrt(1-beta(k,b)^2)*arrayfun(@(omega) random(makedist('Nakagami', 'mu',0.5, 'omega', omega), 1).*exp(2*pi*rand(1)*1j), Mk(:,:,k,b,m).^2);
            end
        end
    end
end


P_0 = zeros(Bx_N,Ux_N,K,Bs);
for b = 1:Bs
    for k = 1:K
        tmp = randn(Bx_N,Ux_N)+randn(Bx_N,Ux_N)*1i;
        P_0(:,:,k,b) = tmp/sqrt(real(trace(tmp*tmp')))*sqrt(Pmax);
    end
end
w =ones(K,Bs);
% load("w.mat");

for i = 1
% [ER0(i), ~] = ER_downlink(H_samples,P_0,sigma(i),w);
[iter_results_aal,time_aal,ER_aal,P1] = Robust_aal(H,Mk,P_0,beta,sigma(i),w,Pmax,H_samples);
% [ER1(i),~]=ER_downlink(H_samples,P1,sigma(i),w);
[iter_results_fast,time_fast,ER_fast,P2] = Robust_downlink_fast(H,Mk,P_0,beta,sigma(i),w,Pmax,H_samples);
% [ER2(i),~]=ER_downlink(H_samples,P2,sigma(i),w);
% [iter_results_fast_con,time_fast_con,ER_fast_con,P6] = Fast_downlink(H,Mk,P_0,beta,sigma(i),w,Pmax,H_samples);
% [ER6(i),~]=ER_downlink(H_samples,P6,sigma(i),w);
[iter_results_fp,time_fp,ER_fp,P3] = Robust_downlink(H,Mk,P_0,beta,sigma(i),w,Pmax,H_samples);
% [ER3(i),~]=ER_downlink(H_samples,P3,sigma(i),w);
[iter_results_WMMSE,timeWMMSE,ER_WMMSE,P4]=WMMSE_downlink(H,Mk,P_0,beta,sigma(i),w,Pmax,H_samples);
% [ER4(i),~]=ER_downlink(H_samples,P4,sigma(i),w);
% [iter_results_SRWMMSE,time_SRWMMSE,ER_SRWMMSE,P5]=Robust_SRWMMSE(H,Mk,P_0,beta,sigma(i),w,Pmax,H_samples);
% [ER5(i),~]=ER_downlink(H_samples,P5,sigma(i),w);
[iter_results_SWMMSE,time_SWMMSE,ER_SWMMSE,P7]=Robust_SWMMSE(H,Mk,P_0,beta,sigma(i),w,Pmax,H_samples);
% [ER7(i),~]=ER_downlink(H_samples,P7,sigma(i),w);
end