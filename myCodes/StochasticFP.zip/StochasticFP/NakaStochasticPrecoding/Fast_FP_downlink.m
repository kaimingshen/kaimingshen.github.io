function [iter_results,time,ER_results,P_star] = Fast_FP_downlink(H_hat,M,U,V,P,beta,sigma,w,Pmax)

[Ux_N, Bx_N, K] = size(H_hat);

H_bar = zeros(Ux_N, Bx_N, K);
for k = 1:K
    H_bar(:,:,k) = beta(k)*H_hat(:,:,k);
end

Y = zeros(Ux_N,Ux_N, K);
gama = zeros(Ux_N,Ux_N, K);

MaxIter = 1000;
iter_results = zeros(MaxIter,1);
ER_results = zeros(MaxIter,1);
[iter_results(1), ~, ~] = obj_func_downlink(H_bar,H_bar,M,U,V,ones(K,1),P,sigma,w);
% [ER_results(1), ~] = ER_downlink(H_hat,M,U,V,beta,P,sigma,w);
time = zeros(MaxIter,1);
eps = 1e-6;
for iter = 2:MaxIter
    if iter>10 && abs(iter_results(iter-1)-iter_results(iter-2))/iter_results(iter-2)<eps
        break
    end
    
    tic

    E_int = zeros(Ux_N, Ux_N, K);
    for k = 1:K
        for l = 1:K
            E_int(:,:,k) = E_int(:,:,k)+EHxxH(H_bar(:,:,k),M(:,:,k),U(:,:,k),V(:,:,k),P(:,:,l),1);
        end
    end

    for k = 1:K
        H_barp = H_bar(:,:,k)*P(:,:,k);
        gama(:,:,k) = H_barp'/(sigma^2*eye(Ux_N)+E_int(:,:,k)-(H_barp*H_barp'))*H_barp;
    end

    for k = 1:K
        Y(:,:,k) = (sigma^2*eye(Ux_N)+E_int(:,:,k))^(-1)*sqrt(w(k))*H_bar(:,:,k)*P(:,:,k);
    end

    Ey_int = zeros(Bx_N, Bx_N);
    for k = 1:K
        Ey_int = Ey_int+EHxyxH(H_bar(:,:,k)',M(:,:,k)',V(:,:,k)',U(:,:,k)',Y(:,:,k),eye(Ux_N)+gama(:,:,k),1);
    end

    lamda = norm(Ey_int,'fro');
    sumP = 0;
    for k = 1:K
       P(:,:,k) = (P(:,:,k))+1/lamda*(sqrt(w(k))*(H_bar(:,:,k))'*(Y(:,:,k))*(eye(Ux_N)+(gama(:,:,k)))-Ey_int*(P(:,:,k)));
       sumP = sumP + real(trace((P(:,:,k))'*(P(:,:,k))));
    end
    if sumP > Pmax
        P = P*sqrt(Pmax/sumP);
    end

    t_run = toc;
    time(iter) = time(iter-1)+t_run;

    [iter_results(iter), R_lb, ~] = obj_func_downlink(H_bar,H_bar,M,U,V,ones(K,1),P,sigma,w);
%     [ER_results(iter), ~] = ER_downlink(H_hat,M,U,V,beta,P,sigma,w);
end
P_star = P;

end