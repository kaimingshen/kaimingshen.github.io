function [iter_results,time,ER_results,P_star] = RWMMSE_downlink(H_hat,M,U,V,P,beta,sigma,w,Pmax)
%UNTITLED5 此处显示有关此函数的摘要
%   P is the beamformer
[Ux_N, Bx_N, K] = size(H_hat);

H_bar = zeros(Ux_N, Bx_N, K);
for k = 1:K
    H_bar(:,:,k) = beta(k)*H_hat(:,:,k);
end

AH = zeros(Ux_N*K,Bx_N);
W = zeros(Ux_N,Ux_N, K); % W in Zhao's paper
X = zeros(Ux_N*K,Ux_N, K); % X in Zhao's paper
U_k = zeros(Ux_N,Ux_N, K);

% initialize W and X
for k = 1:K
    AH(1+(k-1)*Ux_N:k*Ux_N,:) = H_bar(:,:,k);
    W(:,:,k) = eye(Ux_N);
end
barH = AH*AH'; 
barHK = zeros(Ux_N,Ux_N*K, K);
for k = 1:K
    X(:,:,k) = barH\AH*P(:,:,k);
    barHK(:,:,k) = H_bar(:,:,k)*AH';
end

MaxIter = 1000;
iter_results = zeros(MaxIter,1);
ER_results = zeros(MaxIter,1);
[iter_results(1), ~, ~] = obj_func_downlink(H_bar,H_bar,M,U,V,ones(K,1),P,sigma,w);
% [ER_results(1), ~] = ER_downlink(H_hat,M,U,V,beta,P,sigma,w);
time = zeros(MaxIter,1);
eps = 1e-6;

for iter = 2:MaxIter
    if iter>10 && abs(iter_results(iter-1)-iter_results(iter-2))/iter_results(iter-2)<eps
        break
    end
    tic
    %% update U_k
    for k = 1:K
        term1S = zeros(Ux_N,Ux_N); 
        term2S = zeros(Ux_N,Ux_N);
        for i = 1:K
            term1S = term1S+sigma^2/Pmax*trace(X(:,:,i)'*barH*X(:,:,i))*eye(Ux_N);
            HX = barHK(:,:,k)*X(:,:,i);
            term2S = term2S+HX*HX';
        end
        U_k(:,:,k) = pinv(term1S+term2S)*barHK(:,:,k)*X(:,:,k);
    end
    %% update W
    for k = 1:K
        W(:,:,k) = pinv(eye(Ux_N)-U_k(:,:,k)'*barHK(:,:,k)*X(:,:,k));
    end

    %% update X
    UWU = zeros(Ux_N,Ux_N, K);
    for i = 1:K
        UWU(:,:,i) = U_k(:,:,i)*W(:,:,i)*U_k(:,:,i)';
    end
    L = zeros(Ux_N*K,Ux_N*K);
    for i = 1:K
        L = sigma^2/Pmax*w(i)*trace(UWU(:,:,i))*barH+L;
        L = L+w(i)*barHK(:,:,i)'*UWU(:,:,i)*barHK(:,:,i);
    end
    invL = pinv(L);
    eta_do = 0;
    for k = 1:K
        X(:,:,k) = invL*(w(k)*barHK(:,:,k)'*U_k(:,:,k)*W(:,:,k));
        eta_do = eta_do + trace(X(:,:,k)'*barH*X(:,:,k));
    end
    eta = sqrt(Pmax/real(eta_do));
    for k = 1:K
        P(:,:,k) = eta*AH'*X(:,:,k);
    end

    if mod(iter,10) == 0
        t = floor(iter/10)+1;
        t_run = toc;
        time(t) = time(t-1)+t_run;
    
        [iter_results(t), R_lb, ~] = obj_func_downlink(H_bar,H_bar,M,U,V,ones(K,1),P,sigma,w);
%         [ER_results(t), ~] = ER_downlink(H_hat,M,U,V,beta,P,sigma,w);
    end
end
P_star = P;
end