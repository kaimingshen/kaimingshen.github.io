function [eta] = Eta_func(M,C,beta)
    E_s = (1-beta^2)*M.^2;
    mid_term = diag(C);
    eta = diag(E_s*mid_term);
end