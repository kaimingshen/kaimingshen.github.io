function [iter_results,ER_results,P_star] = WMMSE_uplink(H_hat,M,U,V,P,beta,sigma,w,Pmax)

[K, Bx_N, Ux_N] = size(H_hat);

H_bar = H_hat;

Y = zeros(K,Bx_N,Ux_N);
gama = zeros(K,Ux_N,Ux_N);

MaxIter = 1000;
iter_results = zeros(MaxIter,1);
ER_results = zeros(MaxIter,1);
[iter_results(1), ~, ~] = obj_func_uplink(H_hat,H_bar,M,U,V,ones(K,1),P,sigma,w);
[ER_results(1), ~] = ER_uplink(H_hat,M,U,V,beta,P,sigma,w);
% time = zeros(MaxIter,1);
eps = 1e-6;
for iter = 2:MaxIter
    if iter>10 && abs(iter_results(iter-1)-iter_results(iter-2))/iter_results(iter-2)<eps
        break
    end

    E_int = zeros(Bx_N, Bx_N);
    for k = 1:K
        E_int = E_int+EHxxH(squeeze(H_hat(k,:,:)),squeeze(M(k,:,:)),squeeze(U(k,:,:)),squeeze(V(k,:,:)),squeeze(P(k,:,:)),1);
    end

    for k = 1:K
        H_barp = squeeze(H_bar(k,:,:))*squeeze(P(k,:,:));
        gama(k,:,:) = H_barp'/(sigma^2*eye(Bx_N)+E_int-(H_barp*H_barp'))*H_barp;
    end

    for k = 1:K
        Y(k,:,:) = (sigma^2*eye(Bx_N)+E_int)^(-1)*sqrt(w(k))*squeeze(H_bar(k,:,:))*squeeze(P(k,:,:));
    end

    Ey_int = zeros(K, Ux_N, Ux_N);
    for k = 1:K
        for l = 1:K
            Ey_int(k,:,:) = squeeze(Ey_int(k,:,:))+EHxyxH(squeeze(H_hat(k,:,:))',squeeze(M(k,:,:))',squeeze(V(k,:,:))',squeeze(U(k,:,:))',squeeze(Y(l,:,:)),eye(Ux_N)+squeeze(gama(l,:,:)),1);
        end
    end

    for k = 1:K
       P(k,:,:) = updateP_uplink(squeeze(Ey_int(k,:,:)),w(k),squeeze(gama(k,:,:)),squeeze(H_bar(k,:,:)),squeeze(Y(k,:,:)),Pmax);
    end
    [iter_results(iter), R_lb, ~] = obj_func_uplink(H_hat,H_bar,M,U,V,ones(K,1),P,sigma,w);
    [ER_results(iter), ~] = ER_uplink(H_hat,M,U,V,beta,P,sigma,w);
end
P_star = P;

end