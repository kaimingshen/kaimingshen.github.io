% clc; clear; close all;

%% ========== 替换成你自己的数据 ==========

% 横轴：迭代次数（0:1:100）
x_wmmse = timeWMMSE(1:37);
x_alg1   = time_fp(1:37);   
x_alg2   = time_fast(1:37);   
x_rlpd   = time_aal(1:37);   
x_swmmse = time_SWMMSE(1:37);     

% 原始5条曲线（示例数据，可替换）
y_wmmse  = ER_WMMSE(1:37);    
y_alg1   = ER_fp(1:37);   
y_alg2   = ER_fast(1:37);   
y_rlpd   = ER_aal(1:37);   
y_swmmse = ER_SWMMSE(1:37);     


%% === 只取 10 个点显示 marker ===
marker_idx = [1 11 21 31 41 51 61 71 81 101];

%% ========= 画图 =========
figure('Position',[300 200 560 420]);
hold on; grid on;

% WMMSE
plot(x_wmmse, y_wmmse,'--+','Color',[0.8500 0.3250 0.0980], ...
     'LineWidth',1.5,'MarkerSize',6);

% Algorithm 1
plot(x_alg1, y_alg1,'-s','Color',[0.4940 0.1840 0.5560], ...
     'LineWidth',1.5,'MarkerSize',6,'MarkerFaceColor','none');

% Algorithm 2
plot(x_alg2, y_alg2,'-s','Color',[0 0.4470 0.7410], ...
     'LineWidth',1.5,'MarkerSize',6,'MarkerFaceColor','none');

% RLPD
plot(x_rlpd, y_rlpd,':d','Color',[0.4660 0.6740 0.1880], ...
     'LineWidth',1.5,'MarkerSize',6,'MarkerFaceColor','none');

% SWMMSE
plot(x_swmmse, y_swmmse,'--o','Color',[0.9290 0.6940 0.1250], ...
     'LineWidth',1.5,'MarkerSize',6,'MarkerFaceColor','none');


%% ========== 坐标轴 ==========
set(gca,'FontSize',12,'FontName','Times New Roman');
set(gca,'Box','on');

xlabel('Elapsed Time (s)', ...
       'FontSize',14,'FontWeight','normal','Interpreter','latex');

ylabel('Average Sum Rate (bits/s/Hz)', ...
       'FontSize',14,'FontWeight','normal','Interpreter','latex');

xlim([0 2]);
ylim([0 80]);


%% ========== 图例 ==========
legend({'WMMSE','Algorithm 1','Algorithm 2','RLPD','SWMMSE'}, ...
       'FontSize',12,'FontName','Times New Roman', ...
       'Location','southeast','EdgeColor',[0.3 0.3 0.3], ...
       'Interpreter','latex');


%% ========== 网格 ==========
ax = gca;
ax.GridAlpha = 0.25;
ax.XMinorGrid = 'off';
ax.YMinorGrid = 'off';
ax.XMinorTick = 'off';
ax.YMinorTick = 'off';

hold off;
