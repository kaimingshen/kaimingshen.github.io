function [iter_results,time,ER_results,P_star] = WMMSE_downlink_nobis(H_hat,M,P,beta,sigma,w,S,Pmax,users)
%UNTITLED5 此处显示有关此函数的摘要
%   P is the beamformer
[Ux_N, Bx_N, K, Bs] = size(H_hat);

H_bar = zeros(Ux_N, Bx_N, K, Bs);
for k = 1:K
    for b = 1:Bs
        H_bar(:,:,k,b) = beta(k)*H_hat(:,:,k,b);
    end
end

% initialize U
U_k = zeros(Ux_N,Ux_N, K);

MaxIter = 300;
iter_results = zeros(MaxIter,1);
ER_results = zeros(MaxIter,1);
[iter_results(1), ~, ~] = obj_func_downlink(H_hat,H_bar,M,ones(K,1),P,sigma,w);
[ER_results(1), ~] = ER_downlink(H_hat,M,beta,P,sigma,w);
time = zeros(MaxIter,1);
eps = 1e-6;
for iter = 2:MaxIter
    if iter>10 && abs(iter_results(iter-1)-iter_results(iter-2))/iter_results(iter-2)<eps
        break
    end
    tic
    %% update U
    dom = zeros(Ux_N,Ux_N, K);
    for k = 1:K
        for l = 1:K
            dom(:,:,k) = dom(:,:,k)+sigma^2/Pmax*trace(P(:,:,l)*P(:,:,l)')*eye(Ux_N)+H_bar(:,:,k,S(l))*P(:,:,l)*P(:,:,l)'*H_bar(:,:,k,S(l))';
        end
        U_k(:,:,k) = pinv(dom(:,:,k))*H_bar(:,:,k,S(k))*P(:,:,k);
    end
    %% update W
    for k = 1:K
        W(:,:,k) = pinv(eye(Ux_N)-U_k(:,:,k)'*H_bar(:,:,k,S(k))*P(:,:,k));
    end

    %% update X
    UWU = zeros(Ux_N,Ux_N, K);
    bet = 0;
    for i = 1:K
        UWU(:,:,i) = U_k(:,:,i)*W(:,:,i)*U_k(:,:,i)';
        bet = bet + sigma^2/Pmax*w(i)*trace(UWU(:,:,i));
    end

    L = bet*eye(Bx_N);
    for i = 1:K
        L = L+w(i)*H_bar(:,:,i,S(i))'*UWU(:,:,i)*H_bar(:,:,i,S(i));
    end
    invL = pinv(L);
    sumP = 0;
    for k = 1:K
        P(:,:,k) = invL*w(k)*H_bar(:,:,k)'*U_k(:,:,k)*W(:,:,k);
        sumP = sumP + real(trace(P(:,:,k)'*P(:,:,k)));
    end
    P = P*sqrt(Pmax/sumP);

    t_run = toc;
    time(iter) = time(iter-1)+t_run;
%     if time(iter)>1 && iter>2
%         break;
%     end
    P_star = P;

    [iter_results(iter), R_lb, ~] = obj_func_downlink(H_hat,H_bar,M,ones(K,1),P,sigma,w);
    [ER_results(iter), ~] = ER_downlink(H_hat,M,beta,P,sigma,w);
end
%% recover P
% P_star = P;
end