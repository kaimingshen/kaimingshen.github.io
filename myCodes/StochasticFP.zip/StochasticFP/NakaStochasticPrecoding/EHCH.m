function [E] = EHCH(H_hat,M,C,beta)
Aii = diag(C);
B = diag(M.^2*Aii);
E = (H_hat*C*H_hat') + (1-beta^2)*diag(B);
end