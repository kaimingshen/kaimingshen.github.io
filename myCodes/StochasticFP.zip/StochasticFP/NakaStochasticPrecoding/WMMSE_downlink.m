function [iter_results,time,ER_results,P_star] = WMMSE_downlink(H_hat,M,P,beta,sigma,w,Pmax,H_samples)

[Ux_N, Bx_N, K, Bs,~] = size(H_hat);
H_bar = zeros(Ux_N, Bx_N, K, Bs, Bs);
for b = 1:Bs
    for k = 1:K
        for m = 1:Bs
            H_bar(:,:,k,b,m) = beta(k,b)*H_hat(:,:,k,b,m);
        end
    end
end

Y = zeros(Ux_N,Ux_N,K,Bs);
gama = zeros(Ux_N,Ux_N,K,Bs);

MaxIter = 51;
iter_results = zeros(MaxIter,1);
ER_results = zeros(MaxIter,1);
[iter_results(1), ~, ~] = obj_func_downlink(H_bar,H_bar,M,ones(K,Bs),P,sigma,w);
[ER_results(1), ~] = ER_downlink(H_samples,P,sigma,w);
time = zeros(MaxIter,1);
eps = 1e-6;
for iter = 2:MaxIter
    if iter>10 && abs(iter_results(iter-1)-iter_results(iter-2))/iter_results(iter-2)<eps
        break
    end

    tic

    E_int = zeros(Ux_N, Ux_N, K, Bs);
    for b = 1:Bs
        for k = 1:K
            for m = 1:Bs
                for l = 1:K
                    H_hatx = H_bar(:,:,k,b,m)*P(:,:,l,m);
                    E = (H_hatx*H_hatx');
                    E_int(:,:,k,b) = E_int(:,:,k,b)+E;
                    % E_int(:,:,k) = E_int(:,:,k)+EHxxH(H_hat(:,:,k),M(:,:,k),U(:,:,k),V(:,:,k),P(:,:,l),beta(k));
                end
            end
        end
    end
    
    for b = 1:Bs
        for k = 1:K
            H_barp = H_bar(:,:,k,b,b)*P(:,:,k,b);
            gama(:,:,k,b) = H_barp'*pinv(sigma^2*eye(Ux_N)+E_int(:,:,k,b)-(H_barp*H_barp'))*H_barp+eye(Ux_N);
            Y(:,:,k,b) = pinv(sigma^2*eye(Ux_N)+E_int(:,:,k,b))*sqrt(w(k,b))*H_barp;
        end
    end

    Ey_int = zeros(Bx_N, Bx_N, Bs);
    for b = 1:Bs
        for m = 1:Bs
            for l = 1:K
                H_hatx = H_bar(:,:,l,m,b)'*Y(:,:,l,m);
                Ey_int(:,:,b) = Ey_int(:,:,b)+(H_hatx*gama(:,:,l,m)*H_hatx');
                % Ey_int = Ey_int+EHxyxH(H_hat(:,:,k)',M(:,:,k)',V(:,:,k)',U(:,:,k)',Y(:,:,k),eye(Ux_N)+gama(:,:,k),beta(k));
            end
        end
    end

    for b = 1:Bs
       P(:,:,:,b) = updateP_downlink(Ey_int(:,:,b),w(:,b),gama(:,:,:,b),H_bar(:,:,:,b,b),Y(:,:,:,b),Pmax);
%        sumP = 0;
%        for k = 1:K
%             sumP = sumP + real(trace(P(:,:,k,b)'*P(:,:,k,b)));
%        end
%        sumP
    end

    t_run = toc;
    time(iter) = time(iter-1)+t_run;
%     if time(iter)>0.5 && iter>2
%         break;
%     end
    P_star = P;

    [iter_results(iter), R_lb, ~] = obj_func_downlink(H_bar,H_bar,M,ones(K,Bs),P,sigma,w);
    [ER_results(iter), ~] = ER_downlink(H_samples,P,sigma,w);
end
% P_star = P;

end