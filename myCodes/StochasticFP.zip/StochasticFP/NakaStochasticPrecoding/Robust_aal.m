function [iter_results,time,ER_results,P_star] = Robust_aal(H_hat,M,P,beta,sigma,w,Pmax,H_samples)
%UNTITLED5 此处显示有关此函数的摘要
%   此处显示详细说明
[Ux_N, Bx_N, K, Bs,~] = size(H_hat);
H_bar = zeros(Ux_N, Bx_N, K, Bs, Bs);
for b = 1:Bs
    for k = 1:K
        for m = 1:Bs
            H_bar(:,:,k,b,m) = beta(k,b)*H_hat(:,:,k,b,m);
        end
    end
end

MaxIter = 51;
iter_results = zeros(MaxIter,1);
ER_results = zeros(MaxIter,1);
[iter_results(1), ~, ~] = obj_func_downlink(H_hat,H_bar,M,beta,P,sigma,w);
[ER_results(1), ~] = ER_downlink(H_samples,P,sigma,w);
time = zeros(MaxIter,1);
eps = 1e-6;
for iter = 2:MaxIter
%     if iter>10 && abs(iter_results(iter-1)-iter_results(iter-2))/iter_results(iter-2)<eps
%         break
%     end

    tic
    R = zeros(Ux_N,Ux_N, K, Bs);
    A = zeros(Bx_N,Bx_N, K, Bs);
    Ga = zeros(Bx_N,Bx_N, K, Bs);
    Ga_td = zeros(Ux_N,Ux_N, K, Bs);
    B_b = zeros(Bx_N,Bx_N, K, Bs);
    C_b = zeros(Bx_N,Bx_N, K, Bs);
    
    for b = 1:Bs
        for k = 1:K
            %% calculate R
            R(:,:,k,b) = sigma^2*eye(Ux_N);
            for l = 1:K
                if l ~= k 
                    R(:,:,k,b) = R(:,:,k,b)+EHxxH(H_hat(:,:,k,b,b),M(:,:,k,b,b),P(:,:,l,b),beta(k,b));
                end
            end
            invR = pinv(R(:,:,k,b));

            %% calculate A
            A(:,:,k,b) = EHCH(H_hat(:,:,k,b,b)',M(:,:,k,b,b)',invR,beta(k,b));

            %% calculate Gamma and Gamma_td
            R_ms = invR^(1/2);
            G = inv(eye(Ux_N)+P(:,:,k,b)'*P(:,:,k,b));
            G_td = inv(eye(Ux_N)+invR);
            for j = 1:10
                eta_td_G_td = Eta_func(M(:,:,k,b)',R_ms*G_td*R_ms,beta(k,b));
                eta_G = Eta_func(M(:,:,k,b),P(:,:,k,b)*G*P(:,:,k,b)',beta(k,b));
                Phi = eye(Ux_N)+P(:,:,k,b)'*eta_td_G_td*P(:,:,k,b);
                Phi_td = eye(Ux_N)+R_ms*eta_G*R_ms;
                Ga(:,:,k,b)=eta_td_G_td+H_bar(:,:,k,b,b)'*R_ms*pinv(Phi_td)*R_ms*H_bar(:,:,k,b,b);
                Ga_td(:,:,k,b)=eta_G+H_bar(:,:,k,b,b)*P(:,:,k,b)*pinv(Phi)*P(:,:,k,b)'*H_bar(:,:,k,b,b)';
                G = pinv(eye(Ux_N)+P(:,:,k,b)'*Ga(:,:,k,b)*P(:,:,k,b));
                G_td = pinv(eye(Ux_N)+R_ms*Ga_td(:,:,k,b)*R_ms);
            end

            %% calculate B_b
            B_b(:,:,k,b) = A(:,:,k,b)-Ga(:,:,k,b)+Ga(:,:,k,b)*...
                P(:,:,k,b)*pinv(eye(Ux_N)+P(:,:,k,b)'*Ga(:,:,k,b)*P(:,:,k,b))*P(:,:,k,b)'*Ga(:,:,k,b);

            %% calculate C_b
            tmp = invR-inv(R(:,:,k,b)+Ga_td(:,:,k,b));
            C_b(:,:,k,b) = EHCH(H_hat(:,:,k,b,b)',M(:,:,k,b,b)',tmp,beta(k,b));
        end
    end

    %% calculate D_b
    D_b = zeros(Bx_N,Bx_N,Bs);
    F_b = zeros(Bx_N,Bx_N, K,Bs);
    for b = 1:Bs
        for k = 1:K
            D_b(:,:,b) = D_b(:,:,b) + w(k,b)*C_b(:,:,k,b);
        end

    %% calculate F_b
        for k = 1:K
            F_b(:,:,k,b) = w(k,b)*(C_b(:,:,k,b)-B_b(:,:,k,b));
        end

    %% update P
        [P(:,:,:,b)] = updateP_aal(D_b(:,:,b),A(:,:,:,b),F_b(:,:,:,b),P(:,:,:,b),w(:,b),Pmax);


    end


    t_run = toc;
    time(iter) = time(iter-1)+t_run;
%     if time(iter)>0.5 && iter>2
%         break;
%     end
    P_star = P;

    for b = 1:Bs
        for k = 1:K
            iter_results(iter) = iter_results(iter) + real(2*trace((w(k,b)*A(:,:,k,b)+F_b(:,:,k,b))*P(:,:,k,b)*P(:,:,k,b)')-...
                trace(D_b(:,:,b)*P(:,:,k,b)*P(:,:,k,b)'));
        end
    end

    [ER_results(iter), ~] = ER_downlink(H_samples,P,sigma,w);
end
% P_star = P;
end