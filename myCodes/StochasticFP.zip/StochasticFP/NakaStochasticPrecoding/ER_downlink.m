function [EsumR, ER] = ER_downlink(H_samples,P,sigma,w)
[Ux_N, Bx_N, K, Bs,~, N_samples] = size(H_samples);

ER = zeros(K,Bs);
parfor s = 1:N_samples
    R = R_downlink(H_samples(:,:,:,:,:,s), P, sigma,Ux_N, Bx_N, K, Bs);
    ER = ER + R;
end
ER = ER/N_samples;
EsumR = sum(sum(ER.*w));
end

function [R] = R_downlink(H_samples,P,sigma,Ux_N, Bx_N, K, Bs)
R = zeros(K,Bs);
for b = 1:Bs
    for k = 1:K
        int = zeros(Ux_N, Ux_N);
        for m = 1:Bs
            for l = 1:K
                if l~=k || m~=b
                    Hp = H_samples(:,:,k,b,m)*P(:,:,l,m);
                    int = int + Hp*Hp';
                end
            end
        end
        Hp = H_samples(:,:,k,b,b)*P(:,:,k,b);
        R(k,b) = log2(real(det(eye(Ux_N)+Hp'/(sigma^2*eye(Ux_N)+int)*Hp)));
    end
end
end