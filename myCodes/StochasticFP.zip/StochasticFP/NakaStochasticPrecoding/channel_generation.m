Bs_N = 1;
K = 40;
Bx_N = 32;
Ux_N = 1;
fc = 4.8e9;
c = 3e8;
T = 5e-5;


time_s = 100;

H = zeros(time_s, Bs_N, K, Bx_N, Ux_N);
Mk = zeros(Bs_N, K, Bx_N, Ux_N);
Uk = zeros(Bs_N, K, Bx_N, Bx_N);
Vm = zeros(Bs_N, K, Ux_N, Ux_N);

beta = zeros(time_s, Bs_N, K);

Bs_loc = zeros(Bs_N,2);
Rx_loc_sp = zeros(K,3);

for k = 1:K

    Rx_loc_sp(k, 1:2) = rand(1,2)*800-400;
    Rx_loc_sp(k, 3) = 80000;
end

for b = 1:Bs_N
    for k = 1:K
        d = sqrt(sum((Rx_loc_sp(k, 1:2) - Bs_loc(b, :)).^2))/1000;
        Mk(b,k,:,:) = 10.^(-(128.1+37.6*log10(d)+randn(Bx_N,Ux_N)*sqrt(8))/10);
        Uk(b,k,:,:) = eye(Bx_N);
        Vm(b,k,:,:) = eye(Ux_N);
        H(1,b,k,:,:) = reshape(Uk(b,k,:,:),Bx_N,Bx_N) * reshape((Mk(b,k,:,:).*(randn(1,1,Bx_N,Ux_N)/sqrt(2)+randn(1,1,Bx_N,Ux_N)/sqrt(2)*1j)),Bx_N,Ux_N) * reshape(Vm(b,k,:,:),Ux_N,Ux_N);
    end
end
for n = 2:time_s
    for b = 1:Bs_N
        for k = 1:K
            % beta(n, b, k) = abs(besselj(0, 2*pi*n*Rx_loc_sp(k,3)*fc*T/c));
            beta(n, b, k) = gampdf(2*pi*n*Rx_loc_sp(k,3)*fc*T/c/4e4,1,1);
            H(n,b,k,:,:) = beta(n,b,k)*reshape(H(1,b,k,:,:),Bx_N,Ux_N)+sqrt(1-beta(n,b,k)^2)*reshape(Uk(b,k,:,:),Bx_N,Bx_N) * reshape((Mk(b,k,:,:).*(randn(1,1,Bx_N,Ux_N)/sqrt(2)+randn(1,1,Bx_N,Ux_N)/sqrt(2)*1j)),Bx_N,Ux_N) * reshape(Vm(b,k,:,:),Ux_N,Ux_N);
        end
    end
end