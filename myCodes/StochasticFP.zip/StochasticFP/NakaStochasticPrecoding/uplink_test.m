K = 16;
Bx_N = 32;
Ux_N = 2;
fc = 4.8e9;
c = 3e8;
T = 5e-5;
sigma = 10^(-12);
Pmax = 10;
n=2;

H = zeros(K, Bx_N, Ux_N);
Mk = zeros(K, Bx_N, Ux_N);
Uk = zeros(K, Bx_N, Bx_N);
Vm = zeros(K, Ux_N, Ux_N);

beta = zeros(K);

Bs_loc = zeros(Bs_N,2);
Rx_loc_sp = zeros(K,3);

for k = 1:K
    Rx_loc_sp(k, 1:2) = rand(1,2)*8-4;
    Rx_loc_sp(k, 3) = 80000;
end

for k = 1:K
    d = sqrt(sum((Rx_loc_sp(k, 1:2) - Bs_loc(b, :)).^2))/10;
    Mk(k,:,:) = 10.^(-(128.1+37.6*log10(d)+randn(Bx_N,Ux_N)*sqrt(8))/10);
    Uk(k,:,:) = eye(Bx_N);
    Vm(k,:,:) = eye(Ux_N);
    H(k,:,:) = squeeze(Uk(k,:,:)) * squeeze(Mk(k,:,:)).*(randn(Bx_N,Ux_N)/sqrt(2)+randn(Bx_N,Ux_N)/sqrt(2)*1j) * squeeze(Vm(k,:,:));
end

for k = 1:K
    % beta(n, b, k) = abs(besselj(0, 2*pi*n*Rx_loc_sp(k,3)*fc*T/c));
    beta(k) = 0.8;% gampdf(2*pi*n*Rx_loc_sp(k,3)*fc*T/c/4e4,1,1);
end

P_0 = zeros(K,Ux_N,Ux_N);
for k = 1:K
    tmp = randn(Ux_N,Ux_N)+randn(Ux_N,Ux_N)*1i;
    P_0(k,:,:) = tmp/sqrt(real(trace(tmp*tmp')))*sqrt(Pmax);
end
w = ones(K,1);
[iter_results,ER,P] = Robust_uplink(H,Mk,Uk,Vm,P_0,beta,sigma,w,Pmax);
[iter_results_WMMSE, ER_WMMSE,P]=WMMSE_uplink(H,Mk,Uk,Vm,P_0,beta,sigma,w,Pmax);