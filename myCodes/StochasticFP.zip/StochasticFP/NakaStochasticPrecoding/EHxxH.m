function [E] = EHxxH(H_hat,M,x,beta)
A = x*x';
Aii = diag(A);
B = M.^2*Aii;
H_hatx = beta*H_hat*x;
E = (H_hatx*H_hatx') + (1-beta^2)*diag(B);
end