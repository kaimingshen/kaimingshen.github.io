%% CIE Mphil Zhang Yaowen 
% This code is used to find the global optimal solution and it can only be
% used when K=2, since when K=2, the problem can be transferred to a BQP
% problem with a fixed rank
% c is a vector and each component is a complex number max norm (c.'x) can
% be transfered to BQP,c(1) stored the direct channel 
function [x,re]=binary_optimal (c,K)
[N0,~]=size(c);
N=N0-1;
c_N=c(2:N0,1);% c_N is used to store IRS channel informatin 
%%
% for n0=1:N0
%     c2d(n0,1)=real(c(n0,1));
%     c2d(n0,2)=imag(c(n0,1));
%     slope0(n0)=-1*c2d(n0,1)/(c2d(n0,2));
% end
% slope1=sort(slope0);
% for n0=1:N0
%     S0(n0,1)=1;S0(n0,2)=1*slope1(n0);
%     S0(n0+N0,1)=-1;S0(n0+N0,2)=-1*slope1(n0);
% end
% 
% for n0=1:2*N0-1
%     S1(n0,1)=0.5*(S0(n0,1)+S0(n0+1,1));S1(n0,2)=0.5*(S0(n0,2)+S0(n0+1,2));
% end
% S1(2*N0,1)=0.5*(S0(2*N0,1)+S0(1,1));S1(2*N0,2)=0.5*(S0(2*N0,2)+S0(1,2));
%% 
for n0=1:N0
    c_theta(n0,1)=angle(c(n0,1));
    if c_theta(n0,1)<0
        c_theta(n0,1)=c_theta(n0,1)+2*pi;
    end
    for k0=1:2*K-1
    vertical(n0+(k0-1)*N0,1)=c_theta(n0,1)-pi/K*k0;
    if vertical(n0+(k0-1)*N0,1)<0
        vertical(n0,1)=vertical(n0,1)+2*pi;
    end
    end
end
%%
slope_theta=sort(vertical);
% % for n0=1:2*N0
% %     if slope_theta(n0,1)==pi/2
% %         F(n0,1)=0;F(n0,2)=1;
% %     elseif slope_theta(n0,1)==3*pi/2
% %         F(n0,1)=0;F(n0,2)=-1;
% %     else
% %         if slope_theta(n0,1)<pi
% %             F(n0,1)=1;F(n0,2)=tan(slope_theta(n0,1));
% %         else
% %             F(n0,1)=-1;F(n0,2)=-tan(slope_theta(n0,1));
% %     end
% % end
% % end
for n0=1:2*(K-1)*N0-1
    S_theta(n0,1)=(slope_theta(n0,1)+slope_theta(n0+1,1))/2;
end
S_theta(2*(K-1)*N0,1)=mod(0.5*(slope_theta(1,1)+2*pi+slope_theta(2*(K-1)*N0,1)),2*pi);
%%
for n0=1:2*(K-1)*N0
    for n1=1:N0
    temp=floor(mod(abs(S_theta(n0,1)-c_theta(n1,1)),2*pi)/(pi/K));
    if temp<K
        sol(n1,n0)=exp(1j*2*pi/K*temp);
    else
        sol(n1,n0)=exp(1j*2*pi/K*(2*K-temp-1));
    end
    end
end
    for n0=1:2*(K-1)*N0
        b(n0)=abs(c.'*sol(:,n0));
    end
    % find the maximum in b
    [re,index]=max(b);
    x=sol(:,index);
end
