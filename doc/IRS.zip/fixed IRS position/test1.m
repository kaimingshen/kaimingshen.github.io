clc; clear all;
location_BS=[50;-200;20];% unit m
location_IRS=[-2;-1;0];
location_Rx=[0;0;0];
Tx_power=30;% unit dbm;
Rx_noise=-90;% unit dbm;
beta_0=Tx_power-32.6-36.7*log10(norm(location_BS-location_Rx));% unit dbm
beta_n=Tx_power-60-22*log10(norm(location_BS-location_IRS))-22*log10(norm(location_IRS-location_Rx));
N=300;% N is the number of elements in IRS
K=4;
for s0=1:50000
%% Generating channel 
b_0=sqrt(power(10,beta_0/10));
b_n=sqrt(power(10,beta_n/10));
noi=sqrt(power(10,Rx_noise/10));
dc=b_0/sqrt(2)*(randn+1j*randn);
c=b_n/2*(randn(N,1)+1j*randn(N,1)).*(randn(N,1)+1j*randn(N,1));
c=[dc;c];
%% channel estimation
Phi=[1,zeros(1,N);ones(N,1),eye(N)];
x=ones(N+1,1);
X=diag(x);
H=X*Phi;
s=zeros(N+1,1);
T=1;
for t=1:T
s=s+X*Phi*c+noi/sqrt(2)*(randn(N+1,1)+1j*randn(N+1,1));
end
s=s./T;
est_c=inv(H'*H)*H'*s;
%% proposed Algorithm
[x1,x2,x3]=zyw_IRS(est_c,K);
re1=20*log10(abs(c.'*x1));
re2=20*log10(abs(c.'*x2));
re3=20*log10(abs(c.'*x3));
Sim_result(1,s0)=max([re1;re2;re3]);
Sim_result(2,s0)=re1;
%% K=2 global optimum
if K==2
    [x_opt,~]=binary_optimal(est_c,K);
    Sim_result(3,s0)=20*log10(abs(c.'*x_opt));
end

end

cdfplot(Sim_result(1,:));
hold on;
cdfplot(Sim_result(2,:));
% cdfplot(Sim_result(3,:));
Sim_result(2,:)=sort(Sim_result(2,:),2);
Sim_result(1,:)=sort(Sim_result(1,:),2);
if K==2
Sim_result(3,:)=sort(Sim_result(3,:),2);
end
save('K=4,N=300.mat','Sim_result');