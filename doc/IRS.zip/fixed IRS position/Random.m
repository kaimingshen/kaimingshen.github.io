%% CIE Mphil Zhang Yaowen 
% This is for IRS using a Random method
function [x,re]=Random(c,K,T)
% c is the vector n*1 storing Channel estimation and c(1,1) stores the
% direct channel, K is the resolution and T is the number of Sampling
[N0,~]=size(c);
for t0=1:T
    sol(:,t0)=exp(1j.*2*pi/K*floor(K*rand(N0,1)));
    sol(1,t0)=1;
    Re(t0)=abs(c.'*sol(:,t0));
end
[re,index]=max(Re');
x=sol(:,index);
end