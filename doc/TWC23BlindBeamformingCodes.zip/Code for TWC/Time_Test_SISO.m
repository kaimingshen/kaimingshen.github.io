function Time_Test_SISO
U = 1;% number of users
N = 500;% N is the number of elements in IRS % 200= 20*10
% N_L= 50;N_H = 10; % N=N_L*N_H
K = 4;
T = 50;
S = 10;
Rx_noise = -90;% unit dbm;
L = 10;
M = round(N/L);
% location_URx=[0,0,0;0,1,0;1,0,0;1,1,0];% and their location respectively;
% location_IRS=[-2,-1,0]';
% location_BS=[50,-200,20]';
% Tx_power=30;% unit dbm;
load('Channels_SISO_SU_N500.mat','h');
tic;
u0 = 1;
for s = 1:100
    %[opt1(:,u0),opt2(:,u0),opt3(:,u0)]=CondMeanUpMu(N,T*10,h,U,Rx_noise);
    [h_hat,g] = ChanEst_DFT_Group(h,K,1,N,N,Rx_noise);
    H_hat(:,u0) = h_hat; G(:,u0) = g;
    [x_SDR] = Maxmin_SDR(H_hat,U,K,N,1); % opt
end
toc;