%% CUHKSZ-CIE Phd candidsate Shuyi, ECSM
function [opt1,opt2,opt3]=CondMeanUp(N,T,H,U,noise);
h0 = H(1);
H = H(2:N+1);
h = H.';
%size(h)
%h0 = sqrt(nv)*exp(complex(0,unifrnd(0,2*pi,1,1)));
%opt = [];
%noise = eps;

phi_set = [1,1i,-1,-1i];
noise = 10^(noise/20);
f = ones(T,1)*h0;
shift = randi(4,N,T);

for t = 1:T
    z = (randn(1,1)+1i*randn(1,1))*noise/sqrt(2);
    f(t) = f(t) + z;
    for n = 1:N
        f(t) = f(t) + h(n)*phi_set(shift(n,t));
    end
    f(t) = abs(f(t))^2;
end

J = zeros(N,length(phi_set));
J_ind = zeros(N,length(phi_set));
ind_B = [];
ind_C = [];
ind_A = [];
for n = 1:N
    for i = 1:4
        %disp(J(n,i));
        A = find(shift(n,:)==i);
        J(n,i) = mean(f(A));
        %disp(J(n,i));
    end
    [ff,ind] = sort(J(n,:));
    J_out(n,:) = ff;
    J_ind(n,:) = phi_set(ind);
    for i = 1:4
        if J_ind(n,i)==1
            phase(n,i)=0;
        end
        if J_ind(n,i)==1i
            phase(n,i)=1/2;
        end
        if J_ind(n,i)==-1
            phase(n,i)=1;
        end
        if J_ind(n,i)==-1i
            phase(n,i)=3/2;
        end
    end
    a = phase(n,4)+0.5; if a>=2 a=a-2; end
    b = phase(n,4)-0.5; if b<0 b=b+2; end
    if phase(n,3)==b
        ind_B = [ind_B,n];
    elseif phase(n,3)==a
        ind_C = [ind_C,n];
    else
        ind_A = [ind_A,n];
    end
end
1 == 1;
%case1 = abs(h0+h(ind_B)*J_ind(ind_B,4)+h(ind_C)*J_ind(ind_C,3)+h(ind_A)*J_ind(ind_A,4))^2;
%case2 = abs(h0+h(ind_B)*J_ind(ind_B,4)+h(ind_C)*J_ind(ind_C,4)+h(ind_A)*J_ind(ind_A,4))^2;
%case3 = abs(h0+h(ind_B)*J_ind(ind_B,3)+h(ind_C)*J_ind(ind_C,4)+h(ind_A)*J_ind(ind_A,4))^2;
%rel = 10*log10((abs(h0))^2);

% a1 = 10*log10(case1); a2 = 10*log10(case2); a3 = 10*log10(case3);
opt1(1,ind_B+1) = J_ind(ind_B,4); opt1(1,ind_C+1) = J_ind(ind_C,3); opt1(1,ind_A+1) = J_ind(ind_A,4); 
opt2(1,ind_B+1) = J_ind(ind_B,4); opt2(1,ind_C+1) = J_ind(ind_C,4); opt2(1,ind_A+1) = J_ind(ind_A,4); 
opt3(1,ind_B+1) = J_ind(ind_B,3); opt3(1,ind_C+1) = J_ind(ind_C,4); opt3(1,ind_A+1) = J_ind(ind_A,4); 
opt1(1,1) = 1; opt2(1,1) = 1; opt3(1,1) = 1;

