function [H,baseline]=Generate3(xt,yt,zt,xr,yr,zr,x0,y0,z0,N,M,c0,N0)

H = zeros(M,N+1);


%Compute NLOS h_nn g_nn
h_nn = randn(1,N)+1j*randn(1,N);
g_nn = randn(1,N)+1j*randn(1,N);


%Path-Loss of cascaded beta and direct beta0

for m = 1:M
    d1=sqrt((xr-xt)^2+(yr-yt)^2+(zr-zt)^2);
    d2=sqrt((xr-x0)^2+(yr-y0)^2+(zr-z0)^2);
    d3=sqrt((xt-x0)^2+(yt-y0)^2+(zt-z0)^2);
    casc_1=c0-30-22*log10(d2);
    casc_2=-30-22*log10(d3);
    beta1 = sqrt(10^((casc_1+casc_2)/10)); 
    h = beta1/2*g_nn.*h_nn;
    H(m,2:N+1) = h;
    dire=30-32.6-36.7*log10(d1);
    beta0 = sqrt(10^(dire/10));
    H(m,1) = beta0/sqrt(2)*(randn(1,1)+1j*randn(1,1));
end

baseline = 10*log10(beta0^2);


