%% CUHKSZ-CIE Phd candidsate Shuyi, MISO
clc;clear all
U=4;% number of users
N=500;% N is the number of elements in IRS % 200= 20*10
% N_L= 50;N_H = 10; % N=N_L*N_H
K = 4;
T = 500;
S = 100;
Rx_noise=-90;% unit dbm;
M = 4; % #Tx antennas

location_URx=[0,0,0;0,1,0;1,0,0;1,1,0];% and their location respectively;
location_IRS=[-2,-1,0]';
location_BS=[50,-200,20]';
Tx_power=30;% unit dbm;

CSM = zeros(1,S); ECS = zeros(1,S); CSM1 = zeros(1,S); ECS1 = zeros(1,S); TS = zeros(1,S);
for s0=1:S
%% generating channel for U users and Estimation
H = zeros(M,N,U); h0 = zeros(M,U); h = zeros(M,N+1,U);
G = zeros(N+1,U);
opt1 = zeros(N+1,1); opt2 = zeros(N+1,1); opt3 = zeros(N+1,1);
opt1_10 = zeros(N+1,1); opt2_10 = zeros(N+1,1); opt3_10 = zeros(N+1,1);
for u0=1:U
    [h(:,:,u0),~] = Generate3(50,-200,20,-2,-1,0,location_URx(u0,1),location_URx(u0,2),location_URx(u0,3),N,M,Tx_power);
    [H(:,:,u0), h0(:,u0)] = ChanEst_DFT_Miso(h(:,:,u0),K,N,M,Rx_noise,10^(Tx_power/10)/(U*M));
end
%% Twotime_Scale method and Test
[w,opt_TS] = TwoTime_Beamforming(h0,H,N,M,U,Rx_noise,K,Tx_power);
opt_TS = [1;opt_TS].';
%% ECSM CSM
for u0=1:U
    G(1,u0) = h(:,1,u0)'*w(:,u0);
    G(2:N+1,u0) = h(:,2:N+1,u0)'*w(:,u0);
end    
[opt1,opt2,opt3]=CondMeanUpRate(N,T,G,U,Rx_noise);
%[opt1_10(:,1),opt2_10(:,1),opt3_10(:,1)]=CondMeanUpRate(N,T*4,G,U,Rx_noise);
[opt1_10,opt2_10,opt3_10]=CondMeanUpRate(N,T*10,G,U,Rx_noise);
rate_TS = sum_rate(G,opt_TS,U,Rx_noise);
%% Test ECSM CSM
CSM_test = zeros(U,1); ECS_test = zeros(U,1); CSM_10_test = zeros(U,1); ECS_10_test = zeros(U,1); 
a1=sum_rate(G, opt1,U,Rx_noise);
a2=sum_rate(G, opt2,U,Rx_noise);
a3=sum_rate(G, opt3,U,Rx_noise);
CSM_test(1,1)=a2;
ECS_test(1,1)=max([a1,a2,a3]);

b1=sum_rate(G, opt1_10,U,Rx_noise);
b2=sum_rate(G, opt2_10,U,Rx_noise);
b3=sum_rate(G, opt3_10,U,Rx_noise);
CSM_10_test(1,1)=b2;
ECS_10_test(1,1)=max([b1,b2,b3]);

CSM(1,s0)=CSM_test(1,1);
ECS(1,s0)=ECS_test(1,1);
CSM1(1,s0)=CSM_10_test(1,1);
ECS1(1,s0)=ECS_10_test(1,1);
TS(1,s0)=rate_TS; 
s0
end
cdfplot(TS(1,:));
hold on
cdfplot(CSM(1,:));
cdfplot(ECS(1,:));
cdfplot(CSM1(1,:));
cdfplot(ECS1(1,:));
save('MU_N500_K4_U4_TxAn4_50_T2000.mat','TS','ECS','CSM','ECS1','CSM1');