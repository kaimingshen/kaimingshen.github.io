%% Channel estimation
function [h_hat] = ChanEst_OnOff(h,N,M,noi);
h = reshape(h,[(N+1)*M,1]);
Phi=[1,zeros(1,N);ones(N,1),eye(N)];
I = diag(ones(M,1));
Phi = kron(Phi,I);
x=ones((N+1)*M,1);
X=diag(x);
H=X*Phi;
s=zeros((N+1)*M,1);
T=1;
for t=1:T
s=s+X*Phi*h+noi/sqrt(2)*(randn((N+1)*M,1)+1j*randn((N+1)*M,1));
end
s=s./T;
h_hat=inv(H'*H)*H'*s;
h_hat(:,1)=est_c;