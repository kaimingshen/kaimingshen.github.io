%% CUHKSZ-CIE Phd candidsate Shuyi
clc;clear all
U=1;% number of users
N=500;% N is the number of elements in IRS % 200= 20*10
% N_L= 50;N_H = 10; % N=N_L*N_H
K = 4;
T = 50;
S = 10;
Rx_noise=-90;% unit dbm;
L = 10;
M = round(N/L);

location_URx=[0,0,0;0,1,0;1,0,0;1,1,0];% and their location respectively;
location_IRS=[-2,-1,0]';
location_BS=[50,-200,20]';
Tx_power=30;% unit dbm;

for s0=1:S
%% generating channel for U users
H = zeros(N+1,U); H_hat = zeros(N+1,U); H_hat_gro = zeros(M+1,U);
G = zeros(N+1,U); G_gro = zeros(M+1,U);
opt1 = zeros(N+1,U); opt2 = zeros(N+1,U); opt3 = zeros(N+1,U);
opt1_10 = zeros(N+1,U); opt2_10 = zeros(N+1,U); opt3_10 = zeros(N+1,U);
for u0=1:U
    [h,baseline]=Generate3(50,-200,20,-2,-1,0,location_URx(u0,1),location_URx(u0,2),location_URx(u0,3),N,1,Tx_power);
    H(:,u0)=h.'; h = h.';
    %% Method_0 Proposed ECSM and CSM
    [opt1(:,u0),opt2(:,u0),opt3(:,u0)]=CondMeanUpMu(N,T,h,U,Rx_noise);
    [opt1_10(:,u0),opt2_10(:,u0),opt3_10(:,u0)]=CondMeanUpMu(N,T*10,h,U,Rx_noise);
    if K==2
        %% Method_1 LS
        [h_hat,g] = ChanEst_Hadamard_Group(h,K,1,N,N,Rx_noise);
        H_hat(:,u0) = h_hat; G(:,u0) = g;
        %% Method 2 LS with Grouping
        [h_hat,g] = ChanEst_Hadamard_Group(h,K,L,M,N,Rx_noise);
        H_hat_gro(:,u0) = h_hat; G_gro(:,u0) = g;
    else
        %% Method_1 LS
        [h_hat,g] = ChanEst_DFT_Group(h,K,1,N,N,Rx_noise);
        H_hat(:,u0) = h_hat; G(:,u0) = g;
        %% Method 2 LS with Grouping
        [h_hat,g] = ChanEst_DFT_Group(h,K,L,M,N,Rx_noise);
        H_hat_gro(:,u0) = h_hat; G_gro(:,u0) = g;
    end
end
%% SDR method
[x_SDR] = Maxmin_SDR(H_hat,U,K,N,1); % opt
[x_SDR_gro]=Maxmin_SDR(H_hat_gro,U,K,M,1);
SDR_test = zeros(U,1); SDR_test_gro = zeros(U,1); CSM_test = zeros(U,U);
CSM_10_test = zeros(U,U); ECS_test = zeros(U,U); ECS_10_test = zeros(U,U);
%% test the performance of  Algorithms
for u0=1:U
for u1=1:U
    a1=20*log10(abs(H(:,u1).'*opt1(:,u0)));
    a2=20*log10(abs(H(:,u1).'*opt2(:,u0)));
    a3=20*log10(abs(H(:,u1).'*opt3(:,u0)));
    CSM_test(u0,u1)=a2;
    ECS_test(u0,u1)=max([a1,a2,a3]);
    b1=20*log10(abs(H(:,u1).'*opt1_10(:,u0)));
    b2=20*log10(abs(H(:,u1).'*opt2_10(:,u0)));
    b3=20*log10(abs(H(:,u1).'*opt3_10(:,u0)));
    CSM_10_test(u0,u1)=b2;
    ECS_10_test(u0,u1)=max([b1,b2,b3]);
end
SDR_test(u0,1)=20*log10(abs(H(:,u0).'*x_SDR));
SDR_test_gro(u0,1)=20*log10(abs(G_gro(:,u0).'*x_SDR_gro));
CSM_test(u0,1)=min(CSM_test(u0,:));
ECS_test(u0,1)=min(ECS_test(u0,:));
CSM_10_test(u0,1)=min(CSM_10_test(u0,:));
ECS_10_test(u0,1)=min(ECS_10_test(u0,:));
end
CSM(1,s0)=max(CSM_test(:,1))-baseline;
ECS(1,s0)=max(ECS_test(:,1))-baseline;
CSM1(1,s0)=max(CSM_10_test(:,1))-baseline;
ECS1(1,s0)=max(ECS_10_test(:,1))-baseline;
LS(1,s0)=min(SDR_test)-baseline; 
LS_gro(1,s0)=min(SDR_test_gro)-baseline; 
s0
end
cdfplot(LS(1,:));
hold on
cdfplot(LS_gro(1,:));
cdfplot(CSM(1,:));
cdfplot(ECS(1,:));
cdfplot(CSM1(1,:));
cdfplot(ECS1(1,:));
save('Methods_K4_N500_noise90-2.mat','H','LS','LS_gro','ECS','CSM','ECS1','CSM1');