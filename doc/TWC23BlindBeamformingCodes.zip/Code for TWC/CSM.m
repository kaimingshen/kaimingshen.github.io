%% CUHKSZ-CIE Phd candidsate Shuyi
function [rsm,f_best] = CSM(N,K,T,noise,st);
H = exp(complex(0,unifrnd(0,2*pi,1,N)));
h0 = sqrt(st)*exp(complex(0,unifrnd(0,2*pi,1,1)));
Phi = exp(1i*2*pi*(1:K)/K);
theta = unidrnd(K,T,N);
States = Phi(theta);
noise = 10^(noise/10);
rsm = -100000;
for t = 1:T
    the = unifrnd(-pi, pi, 1, 1);
    nn = sqrt(normrnd(0,noise/2,1,1))*(cos(the)+ sin(the)*sqrt(-1));
    f(t) = norm((h0+sum(States(t,1:N).*H))+nn)^2;
    if rsm<f(t)
        rsm = f(t);
        opt_rsm = States(t,:);
    end
end
for n = 1:N
    for k = 1:K
        csm(k) = mean(f(find(States(:,n)==exp(1i*2*pi*k/K))));
    end
    [~,ind] = max(csm);
    opt(n) = exp(1i*2*pi*ind/K);
end
f_best = norm((h0+sum(opt.*H)))^2;