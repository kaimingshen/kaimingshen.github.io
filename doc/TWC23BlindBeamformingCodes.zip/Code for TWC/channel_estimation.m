function [h0_hat, H_hat, out] = channel_estimation(H_in,h0,N,U,noi);
for u = 1:U
    Phi=[1,zeros(1,N);ones(N,1),eye(N)];
    x=ones(N+1,1);
    X=diag(x);
    H=X*Phi;
    s=zeros(N+1,1);
    T=1;
    c = zeros(N+1,1);
    c(1,1)=h0(u); c(2:N+1,1) = H_in(u,:).';
    for t=1:T
        s=s+X*Phi*c+(10^(noi/20))/sqrt(2)*(randn(N+1,1)+1j*randn(N+1,1));
    end
    s=s./T;
    est_c=inv(H'*H)*H'*s;
    H_hat(u,1:N) = est_c(2:N+1);
    h0_hat(u) = est_c(1);
end
out = (sum(abs(H_hat(1,:)-H_in(1,:)).^2)+abs(h0(1)-h0_hat(1))^2)/(N+1);
base = (sum(abs(H_hat(1,:)-0).^2)+abs(h0(1)-0)^2)/(N+1);
%out = out/base;