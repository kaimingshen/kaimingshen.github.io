%% CUHKSZ-CIE Phd candidsate Shuyi, MultiUser Rician
clc;clear all
U=4;% number of users
N=500;% N is the number of elements in IRS % 200= 20*10
N_L= 50;N_H = 10; % N=N_L*N_H
K = 4;
T = 50;
S=100;
Rx_noise=-90;% unit dbm;
L = 10;
M = round(N/L);

location_URx=[0,0,0;0,1,0;1,0,0;1,1,0]';% and their location respectively;
location_IRS=[-2,-1,0;-2,-1,0;-2,-1,0;-2,-1,0]';
location_BS=[50,-200,20;50,-200,20;50,-200,20;50,-200,20]';
Tx_power=30;% unit dbm;

for u0=1:U
d_BU(1,u0)=norm(location_BS-location_URx(:,u0));
d_BR(1,u0)=norm(location_BS-location_IRS);
d_RU(1,u0)=norm(location_IRS-location_URx(:,u0));
beta_0(1,u0)=Tx_power-32.6-36.7*log10(d_BU(1,u0));% unit dbm
beta_n1(1,u0)=-30-22*log10(d_BR(1,u0));
beta_n2(1,u0)=Tx_power-30-22*log10(d_RU(1,u0));
end
baseline=min(beta_0(1,:)');

SDR=zeros(1,S);
c1_LOS=zeros(N,1);c2_LOS=zeros(N,1);
Conti=zeros(1,S);
%% Calculate c1_LOS and c2_LOS
for u0=1:U
    for n0=1:N
        temp1=(location_URx(2,u0)-location_IRS(2,u0))/d_RU(1,u0);
        temp2=(location_URx(3,u0)-location_IRS(3,u0))/d_RU(1,u0);
        temp3=(location_BS(2,u0)-location_IRS(3,u0))/d_BR(1,u0);
        temp4=(location_BS(2,u0)-location_IRS(3,u0))/d_BR(1,u0);
        c1_LOS(n0,u0)=exp(1j*(mod(n0-1,N_L)*(temp1)+floor((n0-1)/N_L)*(temp2)));
        c2_LOS(n0,u0)=exp(1j*(mod(n0-1,N_L)*(temp3)+floor((n0-1)/N_L)*(temp4)));
    end
end
parfor s0=1:S
%% generating channel for U users
H = zeros(N+1,U); H_hat = zeros(N+1,U); H_hat_gro = zeros(M+1,U);
G = zeros(N+1,U); G_gro = zeros(M+1,U);
opt1 = zeros(N+1,U); opt2 = zeros(N+1,U); opt3 = zeros(N+1,U);
opt1_10 = zeros(N+1,U); opt2_10 = zeros(N+1,U); opt3_10 = zeros(N+1,U);
for u0=1:U
    b_0=sqrt(power(10,beta_0(1,u0)/10));
    b_n1=sqrt(power(10,beta_n1(1,u0)/10)); 
    b_n2=sqrt(power(10,beta_n2(1,u0)/10));
    noi=sqrt(power(10,Rx_noise/10));
    dc=b_0/sqrt(2)*(randn+1j*randn);
    fac1 = sqrt(1/2); fac2 = sqrt(1/2);
    c1=b_n1*(fac1*(c1_LOS(:,u0))+fac2*(randn(N,1)+1j*randn(N,1))/sqrt(2));
    c2=b_n2*(fac1*(c2_LOS(:,u0))+fac2*(randn(N,1)+1j*randn(N,1))/sqrt(2));
    c=c1.*c2;
    h=[dc;c];
    H(:,u0)=h;
    %% Method_0 Proposed ECSM and CSM
    [opt1(:,u0),opt2(:,u0),opt3(:,u0)]=CondMeanUpMu(N,T,h,Rx_noise);
    [opt1_10(:,u0),opt2_10(:,u0),opt3_10(:,u0)]=CondMeanUpMu(N,T*10,h,Rx_noise);
    if K==2
        %% Method_1 LS
        [h_hat,g] = ChanEst_Hadamard_Group(h,K,1,N,N,Rx_noise);
        H_hat(:,u0) = h_hat; G(:,u0) = g;
        %% Method 2 LS with Grouping
        [h_hat,g] = ChanEst_Hadamard_Group(h,K,L,M,N,Rx_noise);
        H_hat_gro(:,u0) = h_hat; G_gro(:,u0) = g;
    else
        %% Method_1 LS
        [h_hat,g] = ChanEst_DFT_Group(h,K,1,N,N,Rx_noise);
        H_hat(:,u0) = h_hat; G(:,u0) = g;
        %% Method 2 LS with Grouping
        [h_hat,g] = ChanEst_DFT_Group(h,K,L,M,N,Rx_noise);
        H_hat_gro(:,u0) = h_hat; G_gro(:,u0) = g;
    end
end
%% SDR method
[x_SDR] = Maxmin_SDR(H_hat,U,K,N,1); % opt
[x_SDR_gro]=Maxmin_SDR(H_hat_gro,U,K,M,1);
Ux1_test = zeros(U,1); Ux2_test = zeros(U,1); Ux3_test = zeros(U,1);
SDR_test = zeros(U,1); SDR_test_gro = zeros(U,1); CSM_test = zeros(U,1);
Ux1_10_test = zeros(U,1); Ux2_10_test = zeros(U,1); Ux3_10_test = zeros(U,1);
CSM_10_test = zeros(U,1);
%% test the performance of  Algorithms
for u0=1:U
    Ux1_test(u0,1)=20*log10(abs(H(:,u0).'*opt1(:,u0)));
    Ux2_test(u0,1)=20*log10(abs(H(:,u0).'*opt2(:,u0)));
    Ux3_test(u0,1)=20*log10(abs(H(:,u0).'*opt3(:,u0)));
    SDR_test(u0,1)=20*log10(abs(H(:,u0).'*x_SDR));
    SDR_test_gro(u0,1)=20*log10(abs(G_gro(:,u0).'*x_SDR_gro));
    CSM_test(u0,1)=max([Ux1_test(u0,1),Ux2_test(u0,1),Ux3_test(u0,1)]);
    Ux1_10_test(u0,1)=20*log10(abs(H(:,u0).'*opt1_10(:,u0)));
    Ux2_10_test(u0,1)=20*log10(abs(H(:,u0).'*opt2_10(:,u0)));
    Ux3_10_test(u0,1)=20*log10(abs(H(:,u0).'*opt3_10(:,u0)));
    CSM_10_test(u0,1)=max([Ux1_10_test(u0,1),Ux2_10_test(u0,1),Ux3_10_test(u0,1)]);
end
CSM(1,s0)=min(CSM_test)-baseline;
ECS(1,s0)=max([min(Ux1_test);min(Ux2_test);min(Ux3_test)])-baseline;
CSM1(1,s0)=min(CSM_10_test)-baseline;
ECS1(1,s0)=max([min(Ux1_10_test);min(Ux2_10_test);min(Ux3_10_test)])-baseline;
LS(1,s0)=min(SDR_test)-baseline; 
LS_gro(1,s0)=min(SDR_test_gro)-baseline; 
s0
end
cdfplot(LS(1,:));
hold on
cdfplot(LS_gro(1,:));
cdfplot(CSM(1,:));
cdfplot(ECS(1,:));
cdfplot(CSM1(1,:));
cdfplot(ECS1(1,:));
save('Methods_K2_N500_noise90.mat','H','LS','LS_gro','ECS','CSM','ECS1','CSM1');