function Time_Test_MISO;
U=4;% number of users
N=500;% N is the number of elements in IRS % 200= 20*10
% N_L= 50;N_H = 10; % N=N_L*N_H
T = 500;
K = 4;
Rx_noise=-90;% unit dbm;
M = 4; % #Tx antennas
load('Channels_MISO_MU_N500.mat');
Tx_power=30;% unit dbm;
tic;
for s = 1:100
    %for u0 = 1:U
    %    [H(:,:,u0), h0(:,u0)] = ChanEst_DFT_Miso(h(:,:,u0),K,N,M,Rx_noise,10^(Tx_power/10)/(U*M));
    %end
    %[w,opt_TS] = TwoTime_Beamforming(h0,H,N,M,U,Rx_noise,K,Tx_power);
    w = sqrt((10^(30/10))/(U*M))/sqrt(2)*exp((1j*2*pi*rand(M,U)));
    for u0=1:U
        G(1,u0) = h(:,1,u0)'*w(:,u0);
        G(2:N+1,u0) = h(:,2:N+1,u0)'*w(:,u0);
    end    
    [opt1,opt2,opt3]=CondMeanUpRate(N,T,G,U,Rx_noise);
%[opt1_10(:,1),opt2_10(:,1),opt3_10(:,1)]=CondMeanUpRate(N,T*4,G,U,Rx_noise);
end
toc;