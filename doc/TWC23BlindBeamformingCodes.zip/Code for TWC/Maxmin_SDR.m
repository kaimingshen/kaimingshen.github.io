%% CUHKSZ-CIE Phd candidsate Shuyi, SDR
 function [x_SDR] = Maxmin_SDR(est_Uc,U,K,N,T)
%est_Uc is a (N+1)by U matrix
% T is the number of Gaussion randomization
%% SDR
cvx_begin quiet
% cvx_solver mosek
variable t
variable X(N+1,N+1) complex semidefinite
maximize (t)
subject to
for u0=1:U
    Qi=(est_Uc(:,u0))*est_Uc(:,u0)';
    real(trace(X*Qi))>=t;
end
for n0=1:N+1
    X(n0,n0)==1;
end
cvx_end
%% Projection
% [evec,eval]=eig(X);
% evalues=diag(eval);
% [a,b]=sort(evalues,'descend');
% evectors=evec(:,b);
% x_cvx=evectors(:,1);
% Ang1=angle(x_cvx(1,1));
% if Ang1<0
%     Ang1=Ang1+2*pi;
% end
% for n0=1:N+1
%     Ang=angle(x_cvx(n0,1));
%     if Ang<0
%         Ang=Ang+2*pi;
%     end
%     Ang=Ang-Ang1;
%     if Ang<0
%         Ang=Ang+2*pi;
%     end
%     k=floor(Ang/(2*pi/K));
%     x_SDR(n0,1)=exp(1j*2*pi/K*k);
%end
%% Gaussian randomization 
% X is the optimal solution by SDR, candidate is constructed 
% by w_l=UE^1/2v_l where v_l is a vector of zero mean, unit vari
% variance complex circularly symmetric uncorrelated Gaussian random
% variables.
[V,D]=eig(X);
% size(V)
% size(D)
W_random=V*sqrt(D)*((mvnrnd(zeros(N+1,1),eye(N+1),T)+1j*mvnrnd(zeros(N+1,1),eye(N+1),T)).')./sqrt(2);
% projection 
for t0=1:T
    for n0=1:N+1
        Ang=angle(W_random(n0,t0));
        if Ang<0
            Ang=Ang+2*pi;
        end
        if n0==1
                W_option(n0,t0)=1;
                Ang0=Ang;
        else
            %Ang=Ang-Ang0;
            if Ang<0
                Ang=Ang+2*pi;
            end
            temp1=floor(Ang/(2*pi/K));temp2=mod(Ang,2*pi/K);
            if temp2<pi/K
                W_option(n0,t0)=exp(1j*2*pi/K*(temp1));
            else
                W_option(n0,t0)=exp(1j*2*pi/K*(temp1+1));
            end
        end
    end
end
% maxmin choose the best of all optional solution 
for t0=1:T
    for u0=1:U
        temp3(u0,1)=abs(W_option(:,t0).'*est_Uc(:,u0))^2;
    end
    W_result(t0,1)=min(temp3);
end
[~,index]=max(W_result);
x_SDR=W_option(:,index);

 end

