function [out] = ChanEst_Group(H,N,K,L,M,noi);
% N is N+1, H with h0
i = 1;
omega = [0.5,1,1.5,2];
% h = [h0;H]; 
theta_a = ones(1,L);
eta = [];
psi = 1;
% size(H)
HH = reshape(H(2:N+1),[L,M]);
h(2:M+1,1) = (theta_a*HH).';
h(1,1) = H(1);
m = M+1;
X = diag(ones(1,m));
D_bar = mod((angle(dftmtx(m))/pi),2);
for m1 = 1:m
    for m2 = 1:m
        dis = 100;
        for k = 1:K
            if abs(D_bar(m1,m2)-omega(k))<dis
                dis = abs(D_bar(m1,m2)-omega(k));
                D(m1,m2) = exp(1i*omega(k)*pi);
            end
        end
    end
end
while (i<=L)
    %% Per-group effective channel estimation 
    % Given y=M*1, estimate h_hat=M*1 with designed Theta_s=D=M*M
    y = X*D*h+10^(noi/20)/sqrt(2)*(randn(m,1)+1j*randn(m,1));
    h_hat = (inv(D)*inv(X)*y).'; % M*1;
    %% Intra-group channel estimation 
    % Each group m, collect eta_hat_m_i=i*1; resolve g_hat_m_i=i*1 from eta
    % with designed psi_a_i=i*i
    eta = [eta;h_hat];
    % if method == 1
    %    psi = update_psi1(psi,i); % symmetric
    % else
    %     psi = update_psi2(i); % asymmetric
    % end
    %% Feedback and update
    % AP informs IRS controller of (phi_i)^H, update i=i+1
    i = i+1;
end
psi = update_psi2(L-1); % asymmetric
g = inv(psi)*eta(:,2:m);
H_hat(2:N+1,1) = reshape(g,[N,1]);
H_hat(1,1) = mean(eta(:,1));
out = mean(abs(H_hat-H.').^2);
base = mean(abs(H.'-0).^2);
out = out/base;
%opt = Maxmin_SDR(H_hat,1,4,N,2*N);
%f_best = 20*log10(abs(H.'*opt));