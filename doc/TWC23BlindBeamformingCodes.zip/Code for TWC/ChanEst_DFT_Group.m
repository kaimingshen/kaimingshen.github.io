function [h_hat, g] = ChanEst_DFT_Group(H,K,L,M,N,noi);
omega = [0.5,1,1.5,2];
% phi = exp(1i*pi*(1:K)/K);
h0 = H(1); H = H(2:N+1);
for m = 1:M
    g(m+1,1) = sum(H((m-1)*L+1:m*L));
end
g(1,1) = h0;
X = diag(ones(1,M+1));
D_bar = mod((angle(dftmtx(M+1))/pi),2);
for m1 = 1:M+1
    for m2 = 1:M+1
        dis = 100;
        for k = 1:K
            if abs(D_bar(m1,m2)-omega(k))<dis
                dis = abs(D_bar(m1,m2)-omega(k));
                D(m1,m2) = exp(1i*omega(k)*pi);
            end
        end
    end
end
y = X*D*g+(10^(noi/20))/sqrt(2)*(randn(M+1,1)+1j*randn(M+1,1));
h_hat = inv(D)*inv(X)*y;
%out = trace(inv(D'*D))*fac;
out = sum(abs(g-h_hat).^2)/(M+1);
base = (sum(abs(g)-0).^2)/(M+1);
out = out/base;
