%% CUHKSZ-CIE Phd candidsate Shuyi， IRS-aided SISO, maxmin 
clc;clear all
N = 500;% N is the number of elements in IRS
T = 50;
K = 4;
S = 2000; % Repeating S rounds of experiment.
Rx_noise=-90;% unit dbm;
L = 10; % Size of each group
M = round(N/L);

location_URx=[0,0,0];% and their location respectively;
location_IRS=[-2,-1,0];
location_BS=[50,-200,20];
Tx_power=30;% unit dbm;
H = zeros(N+1,S); H_est = zeros(M+1,S); G = zeros(M+1,S);

out1=zeros(1,S);
parfor s0=1:S
    %% Initial all variables
    est_Uc=zeros(M+1,1);
    %% generating channel for U users and get baseline
    [h,baseline]=Generate3(50,-200,20,-2,-1,0,0,0,0,N,Rx_noise,Tx_power,1);
    H(:,s0)=h;
    %% Method_0 Proposed ECSM and CSM
    [ecs,~,csm,~]=CondMeanUp(N,T,h,Rx_noise);
    [ecs1,~,csm1,~]=CondMeanUp(N,T*10,h,Rx_noise);
    ECS(1,s0) = ecs-baseline; ECS1(1,s0) = ecs1-baseline;
    CSM(1,s0) = csm-baseline; CSM1(1,s0) = csm1-baseline;
    if K==2
        %% Method_1 LS
        [h_hat,g] = ChanEst_Hadamard_Group(h,K,1,N,N,Rx_noise);
        opt = Maxmin_SDR(h_hat,1,K,N,1); % opt
        f_best = 20*log10(abs(g.'*opt));
        Gro1(1,s0)=f_best-baseline; % opt value
        %% Method 2 LS with Grouping
        [h_hat,g] = ChanEst_Hadamard_Group(h,K,L,M,N,Rx_noise);
        opt = Maxmin_SDR(h_hat,1,K,M,1); % opt
        f_best = 20*log10(abs(g.'*opt));
        Gro2(1,s0)=f_best-baseline; % opt value
    else
        %% Method_1 LS
        [h_hat,g] = ChanEst_DFT_Group(h,K,1,N,N,Rx_noise);
        opt = Maxmin_SDR(h_hat,1,K,N,1); % opt
        f_best = 20*log10(abs(g.'*opt));
        Gro1(1,s0)=f_best-baseline; % opt value
        %% Method 2 LS with Grouping
        [h_hat,g] = ChanEst_DFT_Group(h,K,L,M,N,Rx_noise);
        opt = Maxmin_SDR(h_hat,1,K,M,1); % opt
        f_best = 20*log10(abs(g.'*opt));
        Gro2(1,s0)=f_best-baseline; % opt value
    end
    s0
end

cdfplot(Gro1(1,:));
hold on;
cdfplot(Gro2(1,:));
cdfplot(ECS(1,:));
cdfplot(CSM(1,:));
cdfplot(ECS1(1,:));
cdfplot(CSM1(1,:));
save('Methods_K2_N500_noise90.mat','H','Gro1','Gro2','ECS','CSM','ECS1','CSM1');
