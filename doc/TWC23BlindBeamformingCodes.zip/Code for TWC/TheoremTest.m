%% CUHKSZ-CIE Phd candidsate Shuyi， test theorems
NN = 10:20:110;
K = 4;
st = 100;
S = 100; 
Out0 = zeros(length(NN),1); Out1 = zeros(length(NN),1);  Out2 = zeros(length(NN),1); 
for i = 1:length(NN)
N = NN(i);
T = round((N^2)*((log(N))^3));
tic; noise = 0; f = zeros(T,1); y1 = zeros(S,1); y2 = zeros(S,1);
parfor s = 1:S
    H = exp(complex(0,unifrnd(0,2*pi,1,N)));
    h0 = sqrt(st)*exp(complex(0,unifrnd(0,2*pi,1,1)));
    Phi = exp(1i*2*pi*(1:K)/K); noise = 10^(-90/10); opt_cpp = zeros(N,1); cpp = 0;
    %% CCP
    for n = 1:N
        inner = -inf;
        for k = 1:K
            if abs(Phi(k)*H(n)+h0)^2>inner
                inner = abs(Phi(k)*H(n)+h0)^2;
                opt_cpp(n) = Phi(k);
            end
        end
    end
    cpp = norm((h0+sum(opt_cpp.*H.')))^2/(abs(h0)^2);
    %% Sample generation
    theta = unidrnd(4,T,N);
    States = Phi(theta);
    %% Sample test and RSM
    rsm = -inf; f = zeros(T,1); csm = zeros(K,1); 
    opt = zeros(N,1); opt_rsm = zeros(N,1);
    for t = 1:T
        the = unifrnd(-pi, pi, 1, 1);
        nn = sqrt(normrnd(0,noise/2,1,1))*(cos(the)+ sin(the)*sqrt(-1));
        f(t) = norm((h0+sum(States(t,1:N).*H))+nn)^2;
        if rsm<f(t)
            opt_rsm = States(t,:);
        end
    end
    rsm = norm((h0+sum(opt_rsm.*H)))^2/(abs(h0)^2);
    %% CSM
    for n = 1:N
        for k = 1:K
            csm(k) = mean(f(find(States(:,n)==exp(1i*2*pi*k/K))));
        end
        [~,ind] = max(csm);
        opt(n) = exp(1i*2*pi*ind/K);
    end
    f_best = norm((h0+sum(opt.*H.')))^2/(abs(h0)^2);
    y0(s) = cpp; y1(s) = rsm; y2(s) = f_best;
end
toc;
i
Out0(i) = sum(y0)/S; Out1(i) = sum(y1)/S; Out2(i) = sum(y2)/S;
end