function [h_hat, out] = ChanEst_DFT(H,h0,N,K,noi);
omega = [0.5,1,1.5,2];
g(1,1) = h0; g(2:N+1,1) = H.';
X = diag(ones(1,N+1));
D_bar = mod((angle(dftmtx(N+1))/pi),2);
for m1 = 1:N+1
    for m2 = 1:N+1
        dis = 100;
        for k = 1:K
            if abs(D_bar(m1,m2)-omega(k))<dis
                dis = abs(D_bar(m1,m2)-omega(k));
                D(m1,m2) = exp(1i*omega(k)*pi);
            end
        end
    end
end
noi = 0;
y = X*D*g+(10^(noi/20))/sqrt(2)*(randn(N+1,1)+1j*randn(N+1,1));
h_hat = inv(D)*inv(X)*y;
%out = trace(inv(D'*D))*fac;
out = (sum(abs(g-h_hat).^2)/(N+1))/(sum(abs(g-0).^2)/(N+1));

%out = angle(g)-angle(h_hat);
