%Shuyi Ren 2023.01.04. 
function [sol, time] = Arcs_GivenCSI(h0, H, N, K)

h = H.';
% angle difference of hn h0
theta1 = angle(h)-angle(h0);
theta1 = mod(theta1/2/pi*360,360);

time1 = clock;
% Proposed Algorithm
% Calculate lambda_l('arc') and theta_n('opt1', 'opt2') w.r.t. lambda_l
for n = 1:N
    bool(n) = 0;
    for k = 1:K-1
        if theta1(n)>((2*k*180/K)-(180/K)) && theta1(n)<=((2*k*180/K)+(180/K))
            ang(n) = theta1(n)-2*k*180/K;
            if ang(n)<0
                arc(n) = ang(n)+180/K;
                opt1(n) = exp(1i*2*(K-k)*pi/K);
                opt2(n) = opt1(n)*exp(1i*2*pi/K);
                tag(n) = -1;
            else
                arc(n) = ang(n)-180/K;
                opt2(n) = exp(1i*2*(K-k)*pi/K);
                opt1(n) = opt2(n)*exp(-2*1i*pi/K);
                tag(n) = 1;
            end
            bool(n) = 1;
        end
    end
    if bool(n) == 0
        if theta1(n)<=((2*180/K)-(180/K))
            ang(n) = theta1(n);
        else
            ang(n) = theta1(n)-360;
        end
        if ang(n)<0
            arc(n) = ang(n)+180/K;
            opt1(n) = exp(1i*2*0*pi/K);
            opt2(n) = opt1(n)*exp(2*1i*pi/K);
            tag(n) = -1;
        else
            arc(n) = ang(n)-180/K;
            opt2(n) = exp(1i*2*0*pi/K);
            opt1(n) = opt2(n)*exp(-2*1i*pi/K);
            tag(n) = 1;
        end
        bool(n) = 1;
    end
end

% Sort lambda_l and find opt solution
[~,ind] = sort(arc,'descend');
best = abs(h0+sum(h.*opt2))^2;
n0 = 0;
pre = opt1.*h;
lat = opt2.*h;
part1 = sum(pre(ind(1)));
part2 = sum(lat(ind(2:N)));
for n = 2:N
    temp = abs(h0+part1+part2)^2;
    if temp > best
        best = temp;
        n0 = n;
    end
    part1 = part1+pre(ind(n));
    part2 = part2-lat(ind(n));
end
time2 = clock;
time = etime(time2,time1);
sol = 10*log10(best/abs(h0)^2);
opt(1)=1;
opt(ind(1:n0)+1) = opt1(ind(1:n0)); opt(ind(n0+1:N)+1) = opt2(ind(n0+1:N));






