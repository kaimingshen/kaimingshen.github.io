%Shuyi Ren 2023.01.04. 
function [sol, time] = CPP_GivenCSI(h0, H, N, K)

h = H.';
% angle difference of hn h0
theta1 = angle(h)-angle(h0);
theta1 = mod(theta1/2/pi*360,360);

time1 = clock;
% CPP algorithm
for n = 1:N
    bool(n) = 0;
    for k = 1:K-1
        if theta1(n)>((2*k*180/K)-(180/K)) && theta1(n)<=((2*k*180/K)+(180/K))
            ang(n) = theta1(n)-2*k*180/K;
            opt1(n) = exp(1i*2*pi*(K-k)/K);
            bool(n) = 1;
        end
    end
    if bool(n) == 0
        if theta1(n)<=((2*180/K)-(180/K))
            ang(n) = theta1(n);
        else
            ang(n) = theta1(n)-360;
        end
        opt1(n) = exp(1i*2*pi*0/K);
        bool(n) = 1;
    end
end
best = abs(h0+sum(h.*opt1))^2;
sol = 10*log10(best/abs(h0)^2);
time2 = clock;
time = etime(time2,time1);
opt(1) = 1; opt(2:N+1)=opt1(1:N);







