%Shuyi Ren 2023.01.04. 
0. N refers number of elements on IRS;
1. main.m supports comparison among proposed Algorithm 1, CPP and BCD. For small N = 10 with single user task = 'K2_U1_OPT' or 'K4_U1_OPT', we also support one more result of global optimal with greedily enumeration method;
2. Due to the limitation of enumeration, we only show the comparison of global opt and proposed Algorithm 1 with N=10;
3. For number of phase shifts and users, please change 'task' in main.m, e.g., task = 'K4_U4_OPT';
4. Due to the limitation of input locations, we only support U = 1 or U = 4. If you want to try different user number, please remember to change the input locations of user in 'MultiUser_Test.m'.
5. Figure 4, N = 100, task = 'K2_U1_OPT'; Figure 5, N = 100, task = 'K4_U1_OPT'; Figure 6, N = 100, task = 'K2_U4_OPT'
6. Due to the randomness of channel, the result might be slightly different.

* Email Contact: shuyiren@link.cuhk.edu.cn