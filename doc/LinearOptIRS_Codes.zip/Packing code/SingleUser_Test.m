
function [] = SingleUser_Test(N, opts, Tx_power)

    % Calculate the pathloss
    location_IRS = [-2,-1,0]'; %Location of IRS
    location_BS = [50,-200,20]'; %Location of BS
    location_URx = [0,0,0]'; %Location of URx
    beta_0 = Tx_power-32.6-36.7*log10(norm(location_BS-location_URx)); % unit dbm
    beta_n = Tx_power-60-22*log10(norm(location_BS-location_IRS))-22*log10(norm(location_IRS-location_URx));  % unit dbm
    b0 = sqrt(power(10,beta_0/10));
    bn = sqrt(power(10,beta_n/10));
    h0 = b0/sqrt(2)*(randn+1j*randn);

    % Running algorithms for opts.testNum times test
    for test_ind = 1:opts.testNum
        % Generate channel in each test
        h = bn/2*(randn(N,1)+1j*randn(N,1)).*(randn(N,1)+1j*randn(N,1));

        % Running Algorithms in each test
        [ARC_Gain_dB, ARC_time] = Arcs_GivenCSI(h0, h, N, opts.phaseNum);
        [CPP_Gain_dB, CPP_time] = CPP_GivenCSI(h0, h, N, opts.phaseNum);
        [BCD_Gain_dB, BCD_time] = BCD_GivenCSI(h0, h, N, opts.phaseNum, opts.userNum);
        gain_dB = [ARC_Gain_dB, CPP_Gain_dB, BCD_Gain_dB];
        run_time = [ARC_time, CPP_time, BCD_time];

        if (opts.solverNum == 4) && (N==10)
            [OPT_Gain_dB, OPT_time] = OPT_GivenCSI(h0, h, N, opts.phaseNum);
            gain_dB = [gain_dB, OPT_Gain_dB];
            run_time = [run_time, OPT_time];
        end

        out_gain_dB(test_ind, :) = gain_dB;
        out_Time(test_ind, :) = run_time;
    end
    
    for t = 1:opts.solverNum
        aver_Time(t) = mean(out_Time(:,t));
    end
    
    % Figure plots
    figure;
    axes1 = axes;
    hold(axes1,'on');
    solvers = opts.solvers;
    for alg = 1:3
        Gain = sort(out_gain_dB(:, alg));
        alg_name = solvers(alg);
        H = cdfplot(Gain(5:opts.testNum-10));
        if alg_name == "CPP"
            set(H,'DisplayName','CPP','LineWidth',2,'LineStyle','--','Color','b');
            hold on;
        elseif alg_name == "ARC"
            set(H,'DisplayName','Algorithm 1','LineWidth',2,'Color','r');
            hold on;
        elseif alg_name == "BCD"
            set(H,'DisplayName','BCD','MarkerSize',1,'LineWidth',2,...
                'LineStyle','-.','Color',[0.494117647058824 0.184313725490196 0.556862745098039]);
            hold on;
        end
    end
    if (opts.solverNum == 4) && (N==10)
        Gain = out_gain_dB(:, 4);
        alg_name = solvers(4);
        H = cdfplot(Gain);
        set(H,'DisplayName',alg_name,'LineWidth',2,'LineStyle','--','Color','k');
    end
    grid on;
    % Create ylabel
    ylabel('Cumulative Distribution','Interpreter','latex');

    % Create xlabel
    xlabel('SNR Boost (dB)','Interpreter','latex');

    box(axes1,'on');
    grid(axes1,'on');
    % Set the remaining axes properties
    set(axes1,'FontSize',15);
    % Create legend
    legend1 = legend(axes1,'show');
    set(legend1,...
    'Position',[0.149181405930292 0.747708332992739 0.196160997663225 0.157619048300244],...
    'Interpreter','latex',...
    'FontSize',17);
    
    fileName = ['SingleUser Discrete Phase with K=',num2str(opts.phaseNum),'.fig'];
    if opts.saveResults == 1
        filenameVal = fileName;
        savefig(opts.save_path + filenameVal);
    end  
    
    if opts.runTime_display == 1
        for alg = 1:opts.solverNum
            fprintf(solvers(alg) + ':Running Time = %d, \n', aver_Time(alg));
        end
    end
end