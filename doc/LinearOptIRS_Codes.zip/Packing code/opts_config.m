function [opts] = opts_config(N, S, task)
    
    if (N == 10)
        solvers = ["ARC","CPP","BCD","OPT"];
    else
        solvers = ["ARC","CPP","BCD"];
    end
    opts.solvers = solvers;
    opts.solverNum = length(opts.solvers);
    opts.testNum = S;
    
    ind1 = find(task=='K'); ind2 = find(task=='U');
    K = str2num(task(ind1+1:ind2-2));
    phase = exp(1j*2*pi*(1:K)/K);
    opts.phaseNum = K;
    opts.phase = phase;

    ind = find(task=='_');
    U = str2num(task(ind2+1:ind(2)-1));
    opts.userNum = U;
    

    opts.save_path = "./figures/";

end