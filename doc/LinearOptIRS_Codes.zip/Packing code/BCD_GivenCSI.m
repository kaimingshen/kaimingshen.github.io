%Shuyi Ren 2023.01.04. 
function [sol, time] = BCD_GivenCSI(h0, h, N, K, U)
% block coordinate descent that optimize the phase shift one
% by one iteratively, est_Uc is a (N+1) by U matrix
H = [h0;h];
time1 = clock;
X_option=ones(N+1,K);
noi=0;%sqrt(power(10,Rx_noise/10));
obj(1)=0;
iter_maximum=30;
for iter=2:iter_maximum
    for n0=2:N+1
        for k0=1:K
            X_option(n0,k0)=exp(1j*2*pi/K*k0);
            % calculate the performance of K solutions
            for u0=1:U
                Re_KU(k0,u0)=abs(H(:,u0).'*X_option(:,k0)+noi/sqrt(2)*(randn(1,1)+1j*randn(1,1)));
            end
            Re_KU(k0,U+1)=min(Re_KU(k0,1:U)');
        end
        [obj(iter),k_opt]=max(Re_KU(:,U+1));
        X_option(n0,:)=exp(1j*2*pi/K*k_opt)*ones(1,K);
    end
    if obj(iter-1)/obj(iter)>0.99
        break;
    end
end
x_BCD = X_option(:,1);
for u = 1:U
    result(u) = 10*log10((abs(sum(x_BCD.*H(:,u)))^2/abs(H(1,u))^2));
end
sol = min(result);
time2 = clock;
time = etime(time2,time1);
end


