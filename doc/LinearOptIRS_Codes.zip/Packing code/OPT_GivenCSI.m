%Shuyi Ren 2023.01.04.  
function [sol, time] = OPT_GivenCSI(h0, H, N, K)

time1 = clock;
h = H.';
[a1,a2,a3,a4,a5,a6,a7,a8,a9,a10] = ndgrid(1:K);
A = [a1(:),a2(:),a3(:),a4(:),a5(:),a6(:),a7(:),a8(:),a9(:),a10(:)];
phi_set = exp(1i*2*(1:K)*pi/K);
baseline = 10*log10(abs(h0)^2);
phase = phi_set(A);
[l,c] = size(A);
for k = 1:l
    y(k) = abs(sum(phase(k,:).*h)+h0)^2;
end
sol = 10*log10(max(y))-baseline;
time2 = clock;
time = etime(time2,time1);
%out = 10*log10(out)-baseline;