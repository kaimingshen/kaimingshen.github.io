%Shuyi Ren 2023.01.04. 
clc; clear;

%% Params of system
N = 10;% N is the number of elements
S = 2000;
Tx_power = 30; % unit dbm
task = 'K4_U1_OPT';

[opts] = opts_config(N, S, task); 
opts.runTime_display = 1;
opts.saveResults = 1;
if opts.userNum == 1
    SingleUser_Test(N, opts, Tx_power);
else
    MultiUser_Test(N, opts, Tx_power);
end